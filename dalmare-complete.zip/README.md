# Dalmare — Premium E-Commerce Platform

A complete, production-ready luxury e-commerce platform built with Next.js 15, TypeScript, Prisma, PostgreSQL, and Stripe.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | Next.js 15 (App Router), TypeScript, Tailwind CSS |
| Backend | Next.js API Routes |
| Database | PostgreSQL + Prisma ORM |
| Auth | NextAuth v5 (Credentials + Google) |
| Payments | Stripe Checkout + Webhooks |
| Email | Nodemailer (SMTP) |
| State | Zustand (cart) |
| Deployment | Vercel + Neon/Supabase |

---

## Quick Start

### 1. Clone and Install

```bash
git clone https://github.com/your-repo/dalmare.git
cd dalmare
npm install
```

### 2. Environment Variables

Copy `.env.example` to `.env.local` and fill in all values:

```bash
cp .env.example .env.local
```

Required variables:
- `DATABASE_URL` — PostgreSQL connection string
- `NEXTAUTH_SECRET` — Random secret (generate: `openssl rand -base64 32`)
- `STRIPE_SECRET_KEY` — Stripe secret key (sk_test_...)
- `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` — Stripe publishable key (pk_test_...)
- `STRIPE_WEBHOOK_SECRET` — From Stripe CLI or dashboard
- SMTP credentials for email

### 3. Database Setup

```bash
# Generate Prisma client
npm run db:generate

# Run migrations (creates all tables)
npm run db:push

# Seed with sample data
npm run db:seed
```

### 4. Stripe Webhooks (Local)

```bash
# Install Stripe CLI
stripe login
stripe listen --forward-to localhost:3000/api/webhooks/stripe
```

The CLI will show your webhook secret — add it to `STRIPE_WEBHOOK_SECRET`.

### 5. Run Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## Default Accounts (after seeding)

| Role | Email | Password |
|---|---|---|
| Admin | admin@dalmare.com | Admin1234! |
| Customer | test@dalmare.com | Test1234! |

---

## Key URLs

| URL | Description |
|---|---|
| `/` | Homepage |
| `/shop` | Product catalogue |
| `/product/[slug]` | Product detail |
| `/checkout` | Checkout |
| `/login` | Customer login |
| `/register` | Register |
| `/account/dashboard` | Customer account |
| `/admin/dashboard` | Admin panel |

---

## Deployment to Vercel

### 1. Create PostgreSQL database

Use [Neon](https://neon.tech) (free tier available) or [Supabase](https://supabase.com):

```
DATABASE_URL=postgresql://user:pass@host/dalmare?sslmode=require
```

### 2. Deploy to Vercel

```bash
npm install -g vercel
vercel --prod
```

Add all environment variables from `.env.example` in the Vercel dashboard.

### 3. Run migrations on production

```bash
npx prisma migrate deploy
npx tsx prisma/seed.ts
```

### 4. Configure Stripe Webhook (Production)

In Stripe Dashboard → Webhooks → Add endpoint:
- URL: `https://your-domain.com/api/webhooks/stripe`
- Events: `checkout.session.completed`, `checkout.session.expired`, `payment_intent.payment_failed`, `charge.refunded`

---

## Project Structure

```
dalmare/
├── prisma/
│   ├── schema.prisma        # Database schema
│   └── seed.ts              # Sample data
├── src/
│   ├── app/
│   │   ├── (auth)/          # Login, register pages
│   │   ├── (shop)/          # Shop, product, cart, checkout
│   │   ├── (account)/       # Customer dashboard
│   │   ├── (admin)/         # Admin panel
│   │   ├── api/             # API routes
│   │   ├── about/           # About page
│   │   ├── contact/         # Contact + FAQ
│   │   └── privacy-policy/  # Legal pages
│   ├── components/
│   │   ├── layout/          # Navigation, Footer
│   │   ├── home/            # Homepage sections
│   │   ├── shop/            # Product grid, filters
│   │   ├── product/         # Gallery, info, reviews
│   │   ├── cart/            # Cart drawer
│   │   ├── checkout/        # Checkout form
│   │   ├── account/         # Account sidebar
│   │   ├── admin/           # Admin components
│   │   └── ui/              # Toast, skeleton, etc.
│   ├── lib/
│   │   ├── prisma.ts        # DB client
│   │   ├── auth.ts          # NextAuth config
│   │   ├── stripe.ts        # Stripe utils
│   │   ├── cartStore.ts     # Zustand cart
│   │   ├── email.ts         # Nodemailer
│   │   ├── utils.ts         # Helpers
│   │   └── validations.ts   # Zod schemas
│   └── types/
│       └── index.ts         # TypeScript types
└── .env.example
```

---

## Customization

### Brand Colors

Edit `tailwind.config.ts` to change the color palette:

```ts
champagne: { DEFAULT: "#c8a96e" },   // Gold accent
obsidian: { DEFAULT: "#0a0a0a" },    // Deep black
cream: { DEFAULT: "#faf7f0" },       // Warm white
```

### Add a Product

1. Go to `/admin/products/new`
2. Fill in all details and upload images
3. Set category, price, stock
4. Toggle featured/best-seller/new-arrival flags

---

## License

Private — All rights reserved. Dalmare GmbH, Dornbirn, Austria.
