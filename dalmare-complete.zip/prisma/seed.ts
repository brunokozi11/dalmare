import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Seeding Dalmare database...");

  // Admin user
  const adminHash = await bcrypt.hash("Admin1234!", 12);
  const admin = await prisma.user.upsert({
    where: { email: "admin@dalmare.com" },
    update: {},
    create: {
      firstName: "Admin",
      lastName: "Dalmare",
      email: "admin@dalmare.com",
      passwordHash: adminHash,
      role: "ADMIN",
    },
  });
  console.log("✓ Admin user created:", admin.email);

  // Test customer
  const customerHash = await bcrypt.hash("Test1234!", 12);
  const customer = await prisma.user.upsert({
    where: { email: "test@dalmare.com" },
    update: {},
    create: {
      firstName: "Sophie",
      lastName: "Laurent",
      email: "test@dalmare.com",
      passwordHash: customerHash,
      role: "CUSTOMER",
    },
  });
  console.log("✓ Test customer created:", customer.email);

  // Categories
  const categories = await Promise.all([
    prisma.category.upsert({
      where: { slug: "watches" },
      update: {},
      create: {
        name: "Watches",
        slug: "watches",
        description: "Precision timepieces for the discerning collector",
        image: "https://images.unsplash.com/photo-1523170335258-f5ed11844a49?w=600",
      },
    }),
    prisma.category.upsert({
      where: { slug: "jewellery" },
      update: {},
      create: {
        name: "Jewellery",
        slug: "jewellery",
        description: "Handcrafted fine jewellery",
        image: "https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=600",
      },
    }),
    prisma.category.upsert({
      where: { slug: "bracelets" },
      update: {},
      create: {
        name: "Bracelets",
        slug: "bracelets",
        description: "Elegant bracelets for every occasion",
      },
    }),
  ]);
  console.log("✓ Categories created");

  const [watchCategory, jewelleryCategory, braceletCategory] = categories;

  // Products
  const products = [
    {
      name: "Caratello Automatic",
      slug: "caratello-automatic",
      description:
        "The Caratello Automatic is a masterpiece of Italian-inspired design. Its cushion-shaped case houses a Swiss Miyota 9015 hi-beat automatic movement, delivering smooth sweeping seconds and exceptional accuracy. The textured dial features roman numerals and a tasteful date window at 6 o'clock.\n\nThe curved sapphire crystal glass provides superior scratch resistance and anti-reflective clarity. Polished and brushed stainless steel surfaces create a dynamic interplay of light, while the integrated bracelet ensures a comfortable fit on any wrist.",
      details:
        "Movement: Miyota 9015 Automatic (24 jewels, 28,800 bph)\nCase: 316L Stainless Steel, 41mm\nCrystal: Curved Sapphire, AR-coated\nWater Resistance: 5 ATM\nStrap: Integrated stainless steel bracelet with folding clasp",
      categoryId: watchCategory.id,
      price: 289,
      comparePrice: 389,
      stock: 12,
      sku: "DAL-CAR-001",
      images: [
        "https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3?w=800&q=80",
        "https://images.unsplash.com/photo-1614164185128-e4ec99c436d7?w=800&q=80",
        "https://images.unsplash.com/photo-1585123334904-845d60e97b29?w=800&q=80",
      ],
      featured: true,
      bestSeller: true,
      newArrival: false,
      material: "316L Stainless Steel, Sapphire Crystal",
      weight: 145,
    },
    {
      name: "Solara Quartz",
      slug: "solara-quartz",
      description:
        "Clean, refined, endlessly wearable. The Solara Quartz is Dalmare's answer to the perfect everyday dress watch. A slim 7mm profile, sunburst dial, and Japanese Seiko NH35 quartz movement make this an ideal companion for both formal occasions and daily life.",
      details:
        "Movement: Seiko VH31 Quartz\nCase: 316L Stainless Steel, 38mm\nCrystal: Flat Sapphire\nWater Resistance: 3 ATM\nStrap: Genuine leather, quick-release",
      categoryId: watchCategory.id,
      price: 179,
      comparePrice: null,
      stock: 24,
      sku: "DAL-SOL-001",
      images: [
        "https://images.unsplash.com/photo-1612817159949-195b6eb9e31a?w=800&q=80",
        "https://images.unsplash.com/photo-1598531165802-bae60b6c1dc6?w=800&q=80",
      ],
      featured: true,
      bestSeller: false,
      newArrival: true,
      material: "316L Stainless Steel, Genuine Leather",
      weight: 85,
    },
    {
      name: "Arco Steel Bracelet Set",
      slug: "arco-steel-bracelet-set",
      description:
        "The Arco Steel Set is our most popular collection — five interchangeable bracelets designed to suit every mood and moment. From the minimal chain link to the bold Cuban style, this set gives you unparalleled versatility.\n\nEach bracelet is crafted from 316L marine-grade stainless steel with a polished finish that retains its brilliance indefinitely. The magnetic clasp makes wearing and removing effortless.",
      details:
        "Contents: 5 bracelets (chain, Cuban, rope, tennis, flat link)\nMaterial: 316L Stainless Steel\nFinish: High-polished\nClasp: Magnetic box clasp\nSizes: Adjustable 18–22cm",
      categoryId: braceletCategory.id,
      price: 89,
      comparePrice: 129,
      stock: 35,
      sku: "DAL-ARC-001",
      images: [
        "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=800&q=80",
        "https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=800&q=80",
      ],
      featured: true,
      bestSeller: true,
      newArrival: false,
      material: "316L Stainless Steel",
      weight: 65,
    },
    {
      name: "Solara Necklace",
      slug: "solara-necklace",
      description:
        "A delicate yet confident statement. The Solara Necklace features a hand-polished pendant on a fine 50cm chain, both crafted from 316L stainless steel. Subtle enough for everyday wear, striking enough to define an outfit.",
      details:
        "Length: 50cm + 5cm extension\nPendant: 18mm diameter\nMaterial: 316L Stainless Steel\nFinish: Mirror polished\nClasp: Lobster claw",
      categoryId: jewelleryCategory.id,
      price: 69,
      comparePrice: null,
      stock: 42,
      sku: "DAL-SNK-001",
      images: [
        "https://images.unsplash.com/photo-1575863438850-efef8d71b26b?w=800&q=80",
        "https://images.unsplash.com/photo-1506630448388-4e683c67ddb0?w=800&q=80",
      ],
      featured: false,
      bestSeller: false,
      newArrival: true,
      material: "316L Stainless Steel",
      weight: 12,
    },
    {
      name: "Monte Automatic — Rose Gold",
      slug: "monte-automatic-rose-gold",
      description:
        "The Monte Automatic in rose gold PVD is for those who appreciate warmth and distinction. A 40mm case with a domed sapphire crystal and Swiss-quality automatic movement. The warm rose gold tone pairs beautifully with the champagne-coloured dial.",
      details:
        "Movement: Miyota 8215 Automatic\nCase: 316L SS with Rose Gold PVD, 40mm\nCrystal: Domed Sapphire\nWater Resistance: 5 ATM\nStrap: Brown genuine leather, quick-release",
      categoryId: watchCategory.id,
      price: 249,
      comparePrice: 319,
      stock: 8,
      sku: "DAL-MON-RG-001",
      images: [
        "https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=800&q=80",
        "https://images.unsplash.com/photo-1601541895929-9bd0d0c5db75?w=800&q=80",
      ],
      featured: true,
      bestSeller: false,
      newArrival: true,
      material: "316L Stainless Steel, Rose Gold PVD, Sapphire Crystal",
      weight: 120,
    },
    {
      name: "Minimal Ring Set",
      slug: "minimal-ring-set",
      description:
        "Three minimal rings designed to be worn together or separately. Thin-band elegance in polished stainless steel. These rings are hypoallergenic, tarnish-proof, and sized to fit comfortably for extended wear.",
      details:
        "Contents: 3 rings (plain band, twist, open)\nMaterial: 316L Stainless Steel\nFinish: Mirror polished\nSizes: Available in 6, 7, 8, 9, 10",
      categoryId: jewelleryCategory.id,
      price: 49,
      comparePrice: null,
      stock: 60,
      sku: "DAL-RNG-001",
      images: [
        "https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=800&q=80",
      ],
      featured: false,
      bestSeller: true,
      newArrival: false,
      material: "316L Stainless Steel",
      weight: 15,
    },
  ];

  for (const product of products) {
    await prisma.product.upsert({
      where: { slug: product.slug },
      update: product,
      create: product,
    });
    console.log("✓ Product:", product.name);
  }

  // Sample coupon
  await prisma.coupon.upsert({
    where: { code: "WELCOME10" },
    update: {},
    create: {
      code: "WELCOME10",
      type: "percentage",
      value: 10,
      minOrderAmount: 50,
      active: true,
    },
  });
  console.log("✓ Coupon: WELCOME10 (10% off)");

  console.log("\n✅ Seed complete!");
  console.log("   Admin: admin@dalmare.com / Admin1234!");
  console.log("   Test:  test@dalmare.com / Test1234!");
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
