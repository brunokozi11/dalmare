import nodemailer from "nodemailer";

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: parseInt(process.env.SMTP_PORT || "587"),
  secure: process.env.SMTP_PORT === "465",
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASSWORD,
  },
});

type EmailOptions = {
  to: string;
  subject: string;
  html: string;
  text?: string;
};

export async function sendEmail({ to, subject, html, text }: EmailOptions) {
  try {
    await transporter.sendMail({
      from: process.env.EMAIL_FROM || "Dalmare <noreply@dalmare.com>",
      to,
      subject,
      html,
      text,
    });
    return { success: true };
  } catch (error) {
    console.error("Email error:", error);
    return { success: false, error };
  }
}

export function getOrderConfirmationEmail(orderNumber: string, items: any[], total: number) {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <style>
        body { font-family: 'Georgia', serif; background: #faf7f0; color: #0a0a0a; margin: 0; padding: 0; }
        .container { max-width: 600px; margin: 0 auto; padding: 40px 20px; }
        .header { text-align: center; padding: 40px 0; border-bottom: 1px solid #e8e4dc; }
        .logo { font-size: 28px; letter-spacing: 0.3em; font-weight: 300; color: #0a0a0a; }
        .logo span { color: #c8a96e; }
        h2 { font-size: 22px; font-weight: 300; letter-spacing: 0.1em; margin: 40px 0 20px; }
        .order-number { font-family: monospace; background: #e8e4dc; padding: 8px 16px; display: inline-block; letter-spacing: 0.1em; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th { text-align: left; padding: 8px 0; font-size: 11px; letter-spacing: 0.15em; text-transform: uppercase; color: #8a8680; border-bottom: 1px solid #e8e4dc; }
        td { padding: 12px 0; border-bottom: 1px solid #f0ede6; font-size: 14px; font-weight: 300; }
        .total { font-size: 16px; font-weight: 500; color: #c8a96e; }
        .cta { display: inline-block; margin: 30px 0; padding: 14px 32px; background: #0a0a0a; color: #faf7f0; text-decoration: none; font-size: 12px; letter-spacing: 0.2em; text-transform: uppercase; font-family: sans-serif; }
        .footer { text-align: center; margin-top: 40px; padding-top: 30px; border-top: 1px solid #e8e4dc; font-size: 12px; color: #8a8680; letter-spacing: 0.1em; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <div class="logo">DAL<span>MARE</span></div>
          <p style="font-size:12px;letter-spacing:0.2em;color:#8a8680;margin-top:8px;">LUXURY ACCESSORIES</p>
        </div>
        
        <h2>Thank you for your order</h2>
        <p style="font-weight:300;line-height:1.8;">Your order has been confirmed and is being carefully prepared. You will receive a shipping notification once your items are on their way.</p>
        
        <p>Order Number: <span class="order-number">${orderNumber}</span></p>
        
        <table>
          <thead>
            <tr>
              <th>Product</th>
              <th>Qty</th>
              <th>Price</th>
            </tr>
          </thead>
          <tbody>
            ${items.map((item) => `
              <tr>
                <td>${item.name}</td>
                <td>${item.quantity}</td>
                <td>€${parseFloat(item.price).toFixed(2)}</td>
              </tr>
            `).join("")}
          </tbody>
          <tfoot>
            <tr>
              <td colspan="2" style="font-size:12px;letter-spacing:0.15em;text-transform:uppercase;">Total</td>
              <td class="total">€${total.toFixed(2)}</td>
            </tr>
          </tfoot>
        </table>
        
        <a href="${process.env.NEXT_PUBLIC_APP_URL}/account/orders" class="cta">View Your Order</a>
        
        <div class="footer">
          <p>© 2025 Dalmare. All rights reserved.</p>
          <p style="margin-top:8px;">Questions? Contact us at <a href="mailto:info@dalmare.com" style="color:#c8a96e;">info@dalmare.com</a></p>
        </div>
      </div>
    </body>
    </html>
  `;
}
