import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { formatPrice } from "@/lib/utils";
import Link from "next/link";
import { Package, ArrowRight } from "lucide-react";

export default async function DashboardPage() {
  const session = await auth();
  const userId = session!.user!.id!;

  const [recentOrders, orderCount] = await Promise.all([
    prisma.order.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
      take: 5,
      include: { items: true },
    }),
    prisma.order.count({ where: { userId } }),
  ]);

  const statusColors: Record<string, string> = {
    PENDING: "bg-yellow-100 text-yellow-800",
    CONFIRMED: "bg-blue-100 text-blue-800",
    PROCESSING: "bg-indigo-100 text-indigo-800",
    SHIPPED: "bg-purple-100 text-purple-800",
    DELIVERED: "bg-green-100 text-green-800",
    CANCELLED: "bg-red-100 text-red-800",
    REFUNDED: "bg-gray-100 text-gray-800",
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-light text-obsidian">
          Welcome back, {session?.user?.name?.split(" ")[0]}
        </h1>
        <p className="text-sm font-light text-stone-dark mt-1">
          Manage your orders and account details.
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Total Orders", value: orderCount },
          {
            label: "Active Orders",
            value: recentOrders.filter((o) =>
              ["CONFIRMED", "PROCESSING", "SHIPPED"].includes(o.status)
            ).length,
          },
          {
            label: "Total Spent",
            value: formatPrice(
              recentOrders.reduce((s, o) => s + parseFloat(o.total.toString()), 0)
            ),
          },
        ].map((s) => (
          <div key={s.label} className="bg-cream-50 border border-stone/30 p-5 text-center">
            <p className="font-display text-2xl font-light text-champagne">{s.value}</p>
            <p className="text-[10px] tracking-[0.12em] uppercase text-stone-dark mt-1">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Recent Orders */}
      <div className="bg-cream-50 border border-stone/30">
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone/20">
          <h2 className="text-xs tracking-[0.2em] uppercase font-medium text-obsidian">
            Recent Orders
          </h2>
          <Link href="/account/orders" className="text-xs text-champagne hover:text-champagne-dark flex items-center gap-1">
            View All <ArrowRight size={12} />
          </Link>
        </div>

        {recentOrders.length === 0 ? (
          <div className="px-6 py-12 text-center">
            <Package size={36} className="text-stone mx-auto mb-3" strokeWidth={1} />
            <p className="font-display text-lg font-light text-obsidian mb-1">No orders yet</p>
            <p className="text-sm font-light text-stone-dark mb-6">
              Discover our collection and place your first order.
            </p>
            <Link href="/shop" className="btn-primary text-sm">
              Shop Now
            </Link>
          </div>
        ) : (
          <div className="divide-y divide-stone/20">
            {recentOrders.map((order) => (
              <div key={order.id} className="px-6 py-4 flex items-center justify-between gap-4">
                <div>
                  <p className="text-xs font-mono text-obsidian">{order.orderNumber}</p>
                  <p className="text-[10px] text-stone-dark mt-0.5">
                    {new Date(order.createdAt).toLocaleDateString("en-GB")} ·{" "}
                    {order.items.length} item{order.items.length !== 1 ? "s" : ""}
                  </p>
                </div>
                <div className="flex items-center gap-4">
                  <span
                    className={`text-[9px] tracking-[0.1em] uppercase px-2.5 py-1 font-medium ${
                      statusColors[order.status] || "bg-stone text-obsidian"
                    }`}
                  >
                    {order.status.toLowerCase()}
                  </span>
                  <span className="text-sm font-light text-obsidian">
                    {formatPrice(parseFloat(order.total.toString()))}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
