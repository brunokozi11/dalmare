"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { signIn } from "next-auth/react";
import { Eye, EyeOff, Check } from "lucide-react";

export default function RegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const passwordChecks = {
    length: form.password.length >= 8,
    uppercase: /[A-Z]/.test(form.password),
    number: /[0-9]/.test(form.password),
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Registration failed");
        return;
      }

      // Auto sign in
      const result = await signIn("credentials", {
        email: form.email,
        password: form.password,
        redirect: false,
      });

      if (result?.error) {
        router.push("/login");
      } else {
        router.push("/account/dashboard");
      }
    } catch (err) {
      setError("An unexpected error occurred");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-cream-50 flex flex-col">
      <div className="text-center py-10">
        <Link href="/" className="font-display text-2xl tracking-[0.35em] uppercase text-obsidian">
          Dalmare
        </Link>
      </div>

      <div className="flex-1 flex items-center justify-center px-6 pb-16">
        <div className="w-full max-w-sm">
          <div className="text-center mb-10">
            <h1 className="font-display text-3xl font-light text-obsidian mb-2">Create Account</h1>
            <div className="divider-gold" />
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label-luxury">First Name</label>
                <input
                  type="text"
                  value={form.firstName}
                  onChange={(e) => setForm({ ...form, firstName: e.target.value })}
                  required
                  className="input-luxury"
                  placeholder="John"
                />
              </div>
              <div>
                <label className="label-luxury">Last Name</label>
                <input
                  type="text"
                  value={form.lastName}
                  onChange={(e) => setForm({ ...form, lastName: e.target.value })}
                  required
                  className="input-luxury"
                  placeholder="Smith"
                />
              </div>
            </div>

            <div>
              <label className="label-luxury">Email</label>
              <input
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                required
                className="input-luxury"
                placeholder="your@email.com"
              />
            </div>

            <div>
              <label className="label-luxury">Password</label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  required
                  className="input-luxury pr-10"
                  placeholder="Min. 8 characters"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-0 top-1/2 -translate-y-1/2 text-stone-dark hover:text-obsidian"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
              {form.password && (
                <div className="mt-2 space-y-1">
                  {Object.entries({
                    "Minimum 8 characters": passwordChecks.length,
                    "One uppercase letter": passwordChecks.uppercase,
                    "One number": passwordChecks.number,
                  }).map(([label, passed]) => (
                    <div key={label} className="flex items-center gap-2">
                      <Check
                        size={10}
                        className={passed ? "text-green-500" : "text-stone"}
                      />
                      <span
                        className={`text-[10px] font-light ${
                          passed ? "text-green-600" : "text-stone-dark"
                        }`}
                      >
                        {label}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {error && (
              <p className="text-red-500 text-xs font-light bg-red-50 px-3 py-2 border border-red-200">
                {error}
              </p>
            )}

            <p className="text-[10px] font-light text-stone-dark leading-relaxed">
              By creating an account, you agree to our{" "}
              <Link href="/terms" className="text-champagne hover:underline">
                Terms & Conditions
              </Link>{" "}
              and{" "}
              <Link href="/privacy-policy" className="text-champagne hover:underline">
                Privacy Policy
              </Link>
              .
            </p>

            <button
              type="submit"
              disabled={loading || !Object.values(passwordChecks).every(Boolean)}
              className="btn-primary w-full disabled:opacity-50"
            >
              {loading ? "Creating Account..." : "Create Account"}
            </button>
          </form>

          <div className="text-center mt-6">
            <p className="text-xs font-light text-stone-dark">
              Already have an account?{" "}
              <Link href="/login" className="text-champagne hover:text-champagne-dark transition-colors">
                Sign In
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
