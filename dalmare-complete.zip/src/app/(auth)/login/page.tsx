"use client";

import { useState } from "react";
import Link from "next/link";
import { signIn } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";
import { Eye, EyeOff } from "lucide-react";

export default function LoginPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const callbackUrl = searchParams.get("callbackUrl") || "/account/dashboard";
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    const result = await signIn("credentials", {
      email,
      password,
      redirect: false,
    });

    if (result?.error) {
      setError("Invalid email or password");
      setLoading(false);
    } else {
      router.push(callbackUrl);
    }
  };

  return (
    <div className="min-h-screen bg-cream-50 flex flex-col">
      {/* Header */}
      <div className="text-center py-10">
        <Link href="/" className="font-display text-2xl tracking-[0.35em] uppercase text-obsidian">
          Dalmare
        </Link>
      </div>

      {/* Form */}
      <div className="flex-1 flex items-center justify-center px-6 pb-16">
        <div className="w-full max-w-sm">
          <div className="text-center mb-10">
            <h1 className="font-display text-3xl font-light text-obsidian mb-2">Welcome Back</h1>
            <div className="divider-gold" />
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="label-luxury">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="input-luxury"
                placeholder="your@email.com"
              />
            </div>

            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="label-luxury mb-0">Password</label>
                <Link
                  href="/forgot-password"
                  className="text-[10px] tracking-[0.1em] uppercase text-stone-dark hover:text-champagne transition-colors"
                >
                  Forgot Password?
                </Link>
              </div>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="input-luxury pr-10"
                  placeholder="••••••••"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-0 top-1/2 -translate-y-1/2 text-stone-dark hover:text-obsidian transition-colors"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {error && (
              <p className="text-red-500 text-xs font-light bg-red-50 px-3 py-2 border border-red-200">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="btn-primary w-full disabled:opacity-50"
            >
              {loading ? "Signing in..." : "Sign In"}
            </button>
          </form>

          <div className="text-center mt-8">
            <p className="text-xs font-light text-stone-dark">
              New to Dalmare?{" "}
              <Link href="/register" className="text-champagne hover:text-champagne-dark transition-colors">
                Create an Account
              </Link>
            </p>
          </div>

          <Link
            href="/"
            className="flex items-center justify-center mt-8 text-xs font-light text-stone-dark hover:text-obsidian transition-colors"
          >
            ← Continue as Guest
          </Link>
        </div>
      </div>
    </div>
  );
}
