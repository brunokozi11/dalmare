import type { Metadata } from "next";
import { Cormorant_Garamond, Jost, DM_Mono } from "next/font/google";
import "./globals.css";
import { Providers } from "@/components/Providers";
import { Toaster } from "@/components/ui/Toaster";

const cormorant = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  style: ["normal", "italic"],
  variable: "--font-cormorant",
  display: "swap",
});

const jost = Jost({
  subsets: ["latin"],
  weight: ["100", "200", "300", "400", "500", "600", "700"],
  variable: "--font-jost",
  display: "swap",
});

const dmMono = DM_Mono({
  subsets: ["latin"],
  weight: ["300", "400", "500"],
  variable: "--font-dm-mono",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL || "https://dalmare.com"),
  title: {
    default: "Dalmare — Luxury Accessories",
    template: "%s | Dalmare",
  },
  description:
    "Dalmare is a premium lifestyle brand offering exquisitely crafted watches and fine jewellery. Discover timeless elegance and modern sophistication.",
  keywords: ["luxury watches", "fine jewellery", "premium accessories", "Dalmare"],
  authors: [{ name: "Dalmare" }],
  creator: "Dalmare",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://dalmare.com",
    siteName: "Dalmare",
    title: "Dalmare — Luxury Accessories",
    description:
      "Premium watches and fine jewellery. Timeless elegance, modern sophistication.",
    images: [{ url: "/images/og-image.jpg", width: 1200, height: 630 }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Dalmare — Luxury Accessories",
    description: "Premium watches and fine jewellery.",
    images: ["/images/og-image.jpg"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, "max-video-preview": -1, "max-image-preview": "large" },
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${cormorant.variable} ${jost.variable} ${dmMono.variable}`}>
      <body className="font-body bg-cream-50 text-obsidian antialiased">
        <Providers>
          {children}
          <Toaster />
        </Providers>
      </body>
    </html>
  );
}
