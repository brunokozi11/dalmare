import { Navigation } from "@/components/layout/Navigation";
import { Footer } from "@/components/layout/Footer";

export default function ImpressumPage() {
  return (
    <>
      <Navigation />
      <main className="pt-28 min-h-screen">
        <div className="max-w-3xl mx-auto px-6 md:px-12 py-12">
          <div className="mb-10">
            <p className="section-subtitle mb-3">Legal Notice</p>
            <h1 className="section-title">Impressum</h1>
            <div className="divider-gold mt-4 mx-0" />
          </div>

          <div className="space-y-8 text-sm font-light text-obsidian/80 leading-relaxed">
            <div>
              <h2 className="text-xs tracking-[0.2em] uppercase font-medium text-obsidian mb-3">
                Company Information
              </h2>
              <p>Dalmare GmbH</p>
              <p>Weihermähder 15c</p>
              <p>6850 Dornbirn</p>
              <p>Austria</p>
            </div>

            <div>
              <h2 className="text-xs tracking-[0.2em] uppercase font-medium text-obsidian mb-3">
                Contact
              </h2>
              <p>
                Email:{" "}
                <a href="mailto:info@dalmare.com" className="text-champagne hover:underline">
                  info@dalmare.com
                </a>
              </p>
            </div>

            <div>
              <h2 className="text-xs tracking-[0.2em] uppercase font-medium text-obsidian mb-3">
                Registration & Tax
              </h2>
              <p>UID-Nummer: ATU82929725</p>
              <p>Firmenbuchnummer: FN XXXXXX a</p>
              <p>Firmenbuchgericht: Landesgericht Feldkirch</p>
              <p>Handelsgericht: Dornbirn</p>
            </div>

            <div>
              <h2 className="text-xs tracking-[0.2em] uppercase font-medium text-obsidian mb-3">
                Regulatory Information
              </h2>
              <p>Unternehmensgegenstand: Handel mit Uhren und Schmuck</p>
              <p>Mitglied der Wirtschaftskammer Vorarlberg</p>
              <p>Bezirkshauptmannschaft Dornbirn</p>
            </div>

            <div>
              <h2 className="text-xs tracking-[0.2em] uppercase font-medium text-obsidian mb-3">
                Dispute Resolution
              </h2>
              <p>
                The European Commission provides a platform for online dispute resolution (ODR):{" "}
                <a
                  href="https://ec.europa.eu/consumers/odr"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-champagne hover:underline"
                >
                  https://ec.europa.eu/consumers/odr
                </a>
              </p>
              <p className="mt-2">
                We are not obligated to participate in dispute resolution proceedings before a
                consumer arbitration board, but are willing to do so voluntarily.
              </p>
            </div>

            <div>
              <h2 className="text-xs tracking-[0.2em] uppercase font-medium text-obsidian mb-3">
                Liability Disclaimer
              </h2>
              <p>
                Despite careful content control, we assume no liability for the content of
                external links. The operators of linked pages are solely responsible for their
                content. All content on this website is protected by copyright.
              </p>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
