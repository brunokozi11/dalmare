import Link from "next/link";
import { CheckCircle } from "lucide-react";
import { Navigation } from "@/components/layout/Navigation";
import { Footer } from "@/components/layout/Footer";

export default function CheckoutSuccessPage({
  searchParams,
}: {
  searchParams: { order?: string };
}) {
  return (
    <>
      <Navigation />
      <main className="pt-28 min-h-screen bg-stone-light">
        <div className="max-w-2xl mx-auto px-6 py-24 text-center">
          <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-8">
            <CheckCircle size={32} className="text-green-600" />
          </div>

          <p className="text-xs tracking-[0.25em] uppercase text-champagne mb-3">
            Order Confirmed
          </p>
          <h1 className="font-display text-4xl font-light text-obsidian mb-4">
            Thank You For Your Order
          </h1>
          <div className="w-12 h-px bg-champagne mx-auto mb-6" />

          {searchParams.order && (
            <div className="bg-cream-50 border border-stone/30 inline-block px-6 py-3 mb-8">
              <p className="text-[10px] tracking-[0.2em] uppercase text-stone-dark mb-1">Order Number</p>
              <p className="font-mono text-sm font-medium text-obsidian">{searchParams.order}</p>
            </div>
          )}

          <p className="text-sm font-light text-obsidian/70 leading-relaxed mb-10 max-w-md mx-auto">
            We've received your order and are preparing it with care. A confirmation email
            has been sent with your order details. We will notify you once your package
            is on its way.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-12 text-center">
            {[
              { step: "1", label: "Order Confirmed", desc: "We've received it" },
              { step: "2", label: "In Preparation", desc: "Being crafted" },
              { step: "3", label: "On Its Way", desc: "Shipping soon" },
            ].map((s) => (
              <div key={s.step} className="p-4 bg-cream-50 border border-stone/20">
                <p className="font-display text-2xl font-light text-champagne">{s.step}</p>
                <p className="text-xs font-medium tracking-[0.1em] uppercase text-obsidian mt-1">
                  {s.label}
                </p>
                <p className="text-[10px] text-stone-dark mt-0.5">{s.desc}</p>
              </div>
            ))}
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/account/orders" className="btn-primary">
              Track Your Order
            </Link>
            <Link href="/shop" className="btn-secondary">
              Continue Shopping
            </Link>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
