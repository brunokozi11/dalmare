import { Navigation } from "@/components/layout/Navigation";
import { Footer } from "@/components/layout/Footer";
import { CheckoutForm } from "@/components/checkout/CheckoutForm";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Checkout — Dalmare",
  robots: { index: false },
};

export default function CheckoutPage() {
  return (
    <>
      <Navigation />
      <main className="pt-24 min-h-screen bg-stone-light">
        <CheckoutForm />
      </main>
      <Footer />
    </>
  );
}
