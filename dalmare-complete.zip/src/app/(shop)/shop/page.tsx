import { Navigation } from "@/components/layout/Navigation";
import { Footer } from "@/components/layout/Footer";
import { ShopContent } from "@/components/shop/ShopContent";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Shop — Dalmare",
  description: "Browse our complete collection of luxury watches and fine jewellery.",
};

export default function ShopPage({
  searchParams,
}: {
  searchParams: { [key: string]: string | undefined };
}) {
  return (
    <>
      <Navigation />
      <main className="pt-28 min-h-screen">
        <ShopContent searchParams={searchParams} />
      </main>
      <Footer />
    </>
  );
}
