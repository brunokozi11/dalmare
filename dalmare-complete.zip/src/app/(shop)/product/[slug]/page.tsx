import { notFound } from "next/navigation";
import { Navigation } from "@/components/layout/Navigation";
import { Footer } from "@/components/layout/Footer";
import { ProductGallery } from "@/components/product/ProductGallery";
import { ProductInfo } from "@/components/product/ProductInfo";
import { ProductCard } from "@/components/shop/ProductCard";
import { prisma } from "@/lib/prisma";
import type { Metadata } from "next";

type Props = { params: { slug: string } };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const product = await prisma.product.findUnique({
    where: { slug: params.slug, active: true },
  });
  if (!product) return { title: "Product Not Found" };
  return {
    title: `${product.name} — Dalmare`,
    description: product.description.slice(0, 160),
    openGraph: {
      images: product.images[0] ? [{ url: product.images[0] }] : [],
    },
  };
}

export default async function ProductPage({ params }: Props) {
  const product = await prisma.product.findUnique({
    where: { slug: params.slug, active: true },
    include: {
      category: true,
      reviews: {
        where: { approved: true },
        include: { user: { select: { firstName: true, lastName: true, image: true } } },
        orderBy: { createdAt: "desc" },
        take: 10,
      },
    },
  });

  if (!product) notFound();

  const related = await prisma.product.findMany({
    where: { categoryId: product.categoryId, id: { not: product.id }, active: true },
    include: { category: { select: { id: true, name: true, slug: true } } },
    take: 4,
  });

  return (
    <>
      <Navigation />
      <main className="pt-20">
        {/* Breadcrumb */}
        <div className="max-w-7xl mx-auto px-6 md:px-12 py-4">
          <nav className="flex items-center gap-2 text-[10px] tracking-[0.15em] uppercase text-stone-dark">
            <a href="/" className="hover:text-obsidian transition-colors">Home</a>
            <span>/</span>
            <a href="/shop" className="hover:text-obsidian transition-colors">Shop</a>
            <span>/</span>
            <a
              href={`/shop?category=${product.category.slug}`}
              className="hover:text-obsidian transition-colors"
            >
              {product.category.name}
            </a>
            <span>/</span>
            <span className="text-obsidian">{product.name}</span>
          </nav>
        </div>

        {/* Product content */}
        <div className="max-w-7xl mx-auto px-6 md:px-12 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20">
            <ProductGallery images={product.images} name={product.name} />
            <ProductInfo product={product as any} reviews={product.reviews as any} />
          </div>
        </div>

        {/* Related products */}
        {related.length > 0 && (
          <section className="py-16 px-6 md:px-12 border-t border-stone/30">
            <div className="max-w-7xl mx-auto">
              <div className="text-center mb-10">
                <p className="section-subtitle mb-3">You May Also Like</p>
                <h2 className="font-display text-3xl font-light text-obsidian">
                  Related Pieces
                </h2>
                <div className="divider-gold mt-4" />
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 md:gap-8">
                {related.map((p) => (
                  <ProductCard key={p.id} product={p as any} />
                ))}
              </div>
            </div>
          </section>
        )}
      </main>
      <Footer />
    </>
  );
}
