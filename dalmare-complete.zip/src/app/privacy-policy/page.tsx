import { Navigation } from "@/components/layout/Navigation";
import { Footer } from "@/components/layout/Footer";

export default function PrivacyPolicyPage() {
  return (
    <>
      <Navigation />
      <main className="pt-28 min-h-screen">
        <div className="max-w-3xl mx-auto px-6 md:px-12 py-12">
          <div className="mb-10">
            <p className="section-subtitle mb-3">Legal</p>
            <h1 className="section-title">Privacy Policy</h1>
            <div className="divider-gold mt-4 mx-0" />
            <p className="text-xs text-stone-dark font-light mt-4">Last updated: June 2025</p>
          </div>

          <div className="prose-luxury space-y-8 text-sm font-light text-obsidian/80 leading-relaxed">
            {[
              {
                title: "1. Introduction",
                content: `Dalmare GmbH ("we", "our", "us"), registered at Weihermähder 15c, 6850 Dornbirn, Austria (UID: ATU82929725), is committed to protecting your personal data. This Privacy Policy explains how we collect, use, and safeguard your information when you use our website and services.`,
              },
              {
                title: "2. Data We Collect",
                content: `We collect information you provide directly, including: name, email address, shipping and billing addresses, phone number, and payment information (processed securely by Stripe — we never store card details). We also collect usage data such as browser type, IP address, and pages visited.`,
              },
              {
                title: "3. How We Use Your Data",
                content: `We use your data to: process and fulfil orders; communicate about your order status; send marketing emails (with your consent); improve our website and services; comply with legal obligations under Austrian and EU law.`,
              },
              {
                title: "4. Data Sharing",
                content: `We do not sell your personal data. We share data only with: payment processors (Stripe), shipping carriers, email service providers, and analytics tools — all under strict data processing agreements. We may disclose data where legally required.`,
              },
              {
                title: "5. Your Rights (GDPR)",
                content: `Under the GDPR, you have the right to: access your personal data; rectify inaccurate data; request erasure ("right to be forgotten"); restrict or object to processing; data portability; withdraw consent at any time. Contact us at info@dalmare.com to exercise these rights.`,
              },
              {
                title: "6. Cookies",
                content: `We use essential cookies for site functionality and optional cookies for analytics. You can manage cookie preferences in your browser settings or via our cookie consent tool.`,
              },
              {
                title: "7. Data Retention",
                content: `We retain your data for as long as necessary to fulfil the purposes outlined in this policy, or as required by law. Order data is retained for 7 years per Austrian tax regulations.`,
              },
              {
                title: "8. Contact",
                content: `For privacy inquiries: Dalmare GmbH, Weihermähder 15c, 6850 Dornbirn, Austria. Email: info@dalmare.com`,
              },
            ].map((section) => (
              <div key={section.title}>
                <h2 className="text-sm font-medium tracking-[0.05em] text-obsidian mb-3">
                  {section.title}
                </h2>
                <p>{section.content}</p>
              </div>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
