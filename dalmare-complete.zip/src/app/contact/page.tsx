"use client";

import { useState } from "react";
import { Navigation } from "@/components/layout/Navigation";
import { Footer } from "@/components/layout/Footer";
import { Mail, MapPin, Clock, ChevronDown } from "lucide-react";

const faqs = [
  {
    q: "How long does shipping take?",
    a: "Standard international shipping takes 7–14 business days. Express options are available at checkout. All orders include tracking.",
  },
  {
    q: "What is your return policy?",
    a: "We offer 30-day hassle-free returns on all unworn items in original packaging. Simply contact us and we'll arrange a return label.",
  },
  {
    q: "What does the Lifetime Guarantee cover?",
    a: "Our Lifetime Guarantee covers any tarnishing, fading, or manufacturing defects. Send us a photo and your order number to info@dalmare.com and we will replace the item at no cost.",
  },
  {
    q: "Are your pieces water resistant?",
    a: "All our jewellery and watches are crafted from 316L marine-grade stainless steel and are water resistant. They can withstand rain, showering, and swimming.",
  },
  {
    q: "Do you ship worldwide?",
    a: "Yes, we offer free worldwide shipping on all orders over €150. For orders under this amount, a flat shipping fee of €9.99 applies.",
  },
  {
    q: "How can I track my order?",
    a: "Once your order ships, you'll receive a tracking number by email. You can also track your order in your account dashboard.",
  },
];

export default function ContactPage() {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus("loading");
    // Simulated — wire up to /api/contact
    await new Promise((r) => setTimeout(r, 1200));
    setStatus("success");
  };

  return (
    <>
      <Navigation />
      <main className="pt-28 min-h-screen">
        <div className="max-w-7xl mx-auto px-6 md:px-12 py-12">
          {/* Header */}
          <div className="text-center mb-16">
            <p className="section-subtitle mb-3">Get in Touch</p>
            <h1 className="section-title mb-4">Contact Us</h1>
            <div className="divider-gold" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-16">
            {/* Contact info */}
            <div className="lg:col-span-2 space-y-8">
              <div>
                <h2 className="font-display text-2xl font-light text-obsidian mb-6">
                  We'd Love to Hear From You
                </h2>
                <p className="text-sm font-light text-obsidian/70 leading-relaxed">
                  Whether you have a question about a product, need help with your order,
                  or simply want to say hello — our team is here for you.
                </p>
              </div>

              {[
                {
                  icon: Mail,
                  title: "Email",
                  value: "info@dalmare.com",
                  href: "mailto:info@dalmare.com",
                },
                {
                  icon: MapPin,
                  title: "Address",
                  value: "Dalmare GmbH\nWeihermähder 15c\n6850 Dornbirn, Austria",
                  href: null,
                },
                {
                  icon: Clock,
                  title: "Response Time",
                  value: "We typically respond within 24 hours on business days.",
                  href: null,
                },
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <div key={item.title} className="flex gap-4">
                    <div className="w-10 h-10 border border-champagne/30 flex items-center justify-center flex-shrink-0">
                      <Icon size={16} className="text-champagne" strokeWidth={1.5} />
                    </div>
                    <div>
                      <p className="text-[10px] tracking-[0.2em] uppercase text-stone-dark mb-1">
                        {item.title}
                      </p>
                      {item.href ? (
                        <a
                          href={item.href}
                          className="text-sm font-light text-obsidian hover:text-champagne transition-colors"
                        >
                          {item.value}
                        </a>
                      ) : (
                        <p className="text-sm font-light text-obsidian whitespace-pre-line">
                          {item.value}
                        </p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Form */}
            <div className="lg:col-span-3">
              {status === "success" ? (
                <div className="bg-green-50 border border-green-200 p-10 text-center">
                  <p className="font-display text-2xl font-light text-green-700 mb-2">
                    Message Sent!
                  </p>
                  <p className="text-sm font-light text-green-600">
                    Thank you for reaching out. We'll be in touch within 24 hours.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <label className="label-luxury">Name</label>
                      <input
                        type="text"
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                        required
                        className="input-luxury"
                        placeholder="Your full name"
                      />
                    </div>
                    <div>
                      <label className="label-luxury">Email</label>
                      <input
                        type="email"
                        value={form.email}
                        onChange={(e) => setForm({ ...form, email: e.target.value })}
                        required
                        className="input-luxury"
                        placeholder="your@email.com"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="label-luxury">Subject</label>
                    <input
                      type="text"
                      value={form.subject}
                      onChange={(e) => setForm({ ...form, subject: e.target.value })}
                      required
                      className="input-luxury"
                      placeholder="How can we help you?"
                    />
                  </div>
                  <div>
                    <label className="label-luxury">Message</label>
                    <textarea
                      value={form.message}
                      onChange={(e) => setForm({ ...form, message: e.target.value })}
                      required
                      rows={6}
                      className="input-luxury resize-none"
                      placeholder="Tell us more..."
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={status === "loading"}
                    className="btn-primary disabled:opacity-50"
                  >
                    {status === "loading" ? "Sending..." : "Send Message"}
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* FAQ */}
          <section className="mt-24" id="faq">
            <div className="text-center mb-12">
              <p className="section-subtitle mb-3">FAQ</p>
              <h2 className="section-title">Frequently Asked Questions</h2>
              <div className="divider-gold mt-4" />
            </div>
            <div className="max-w-3xl mx-auto divide-y divide-stone/30">
              {faqs.map((faq, i) => (
                <div key={i}>
                  <button
                    onClick={() => setOpenFaq(openFaq === i ? null : i)}
                    className="w-full flex items-center justify-between py-5 text-left"
                  >
                    <span className="text-sm font-light text-obsidian pr-8">{faq.q}</span>
                    <ChevronDown
                      size={16}
                      className={`text-champagne flex-shrink-0 transition-transform duration-300 ${
                        openFaq === i ? "rotate-180" : ""
                      }`}
                    />
                  </button>
                  {openFaq === i && (
                    <p className="text-sm font-light text-obsidian/70 leading-relaxed pb-5 animate-fade-in">
                      {faq.a}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </section>
        </div>
      </main>
      <Footer />
    </>
  );
}
