import Image from "next/image";
import Link from "next/link";
import { Navigation } from "@/components/layout/Navigation";
import { Footer } from "@/components/layout/Footer";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "About — Dalmare",
  description: "Discover the Dalmare story — a passion for timeless elegance and fine craftsmanship.",
};

export default function AboutPage() {
  return (
    <>
      <Navigation />
      <main className="pt-20">
        {/* Hero */}
        <section className="relative h-[50vh] min-h-[400px] overflow-hidden">
          <Image
            src="https://images.unsplash.com/photo-1588702547923-7093a6c3ba33?w=1600&q=80"
            alt="Dalmare atelier"
            fill
            priority
            className="object-cover"
          />
          <div className="absolute inset-0 bg-obsidian/50" />
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-6">
            <p className="text-[11px] tracking-[0.4em] uppercase text-champagne mb-3">Our Story</p>
            <h1 className="font-display text-display-xl font-light text-white">About Dalmare</h1>
          </div>
        </section>

        {/* Mission */}
        <section className="py-24 px-6 md:px-12">
          <div className="max-w-4xl mx-auto text-center">
            <p className="section-subtitle mb-4">Our Mission</p>
            <h2 className="font-display text-4xl md:text-5xl font-light text-obsidian leading-tight mb-6">
              Crafting <em className="italic text-champagne">Timeless</em> Pieces<br />
              for the Discerning Few
            </h2>
            <div className="divider-gold mb-8" />
            <p className="text-base font-light text-obsidian/70 leading-relaxed max-w-2xl mx-auto">
              Dalmare was founded on a simple belief: that true luxury is not about price tags or
              logos — it's about the quiet confidence that comes from wearing something perfectly
              made. Every piece in our collection is a result of countless hours of refinement,
              thoughtful material selection, and an unwavering commitment to quality.
            </p>
          </div>
        </section>

        {/* Story sections */}
        {[
          {
            title: "Born from Passion",
            subtitle: "The Beginning",
            text: "Dalmare began in 2018 when founder Alessandro Marin combined his passion for Italian watchmaking traditions with a modern, accessible vision. Having spent years studying horology in Switzerland and design in Milan, Alessandro set out to create a brand that bridged the gap between genuine quality and everyday wearability.",
            image: "https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=800&q=80",
            reverse: false,
          },
          {
            title: "Material Excellence",
            subtitle: "Our Craft",
            text: "We source only the finest 316L marine-grade stainless steel, sapphire crystal glass, and precision-engineered movements. Each material is chosen not just for its aesthetic quality but for its ability to withstand the test of time. Our jewellery is crafted to be worn daily, through life's adventures, retaining its beauty for decades.",
            image: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=800&q=80",
            reverse: true,
          },
          {
            title: "A Lifetime Promise",
            subtitle: "Our Guarantee",
            text: "Every Dalmare piece comes with our Lifetime Guarantee. We stand behind the quality of our craftsmanship completely. If any piece tarnishes, fades, or develops a defect, we will replace it — no questions asked. This isn't just a policy; it's a reflection of our confidence in what we create.",
            image: "https://images.unsplash.com/photo-1523170335258-f5ed11844a49?w=800&q=80",
            reverse: false,
          },
        ].map((section) => (
          <section
            key={section.title}
            className="py-16 px-6 md:px-12 border-t border-stone/20"
          >
            <div
              className={`max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center ${
                section.reverse ? "lg:flex lg:flex-row-reverse" : ""
              }`}
            >
              <div className="relative aspect-[4/3] overflow-hidden">
                <Image
                  src={section.image}
                  alt={section.title}
                  fill
                  className="object-cover"
                  sizes="(max-width: 1024px) 100vw, 50vw"
                />
              </div>
              <div className={section.reverse ? "lg:pr-8" : "lg:pl-8"}>
                <p className="section-subtitle mb-3">{section.subtitle}</p>
                <h2 className="font-display text-3xl md:text-4xl font-light text-obsidian mb-6">
                  {section.title}
                </h2>
                <div className="divider-gold mb-6 mx-0" />
                <p className="text-sm font-light text-obsidian/70 leading-relaxed">
                  {section.text}
                </p>
              </div>
            </div>
          </section>
        ))}

        {/* Values */}
        <section className="py-20 px-6 md:px-12 bg-obsidian">
          <div className="max-w-5xl mx-auto text-center">
            <p className="section-subtitle text-champagne mb-3">What We Stand For</p>
            <h2 className="font-display text-4xl font-light text-cream-50 mb-4">Our Values</h2>
            <div className="divider-gold mb-16" />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
              {[
                {
                  title: "Quality First",
                  text: "We never compromise on materials or craftsmanship, regardless of cost.",
                },
                {
                  title: "Timeless Design",
                  text: "We create pieces that transcend trends and remain beautiful for a lifetime.",
                },
                {
                  title: "Customer Promise",
                  text: "Your satisfaction is guaranteed — forever. That's the Dalmare commitment.",
                },
              ].map((v) => (
                <div key={v.title}>
                  <div className="w-8 h-px bg-champagne mx-auto mb-6" />
                  <h3 className="font-display text-xl font-light text-cream-50 mb-3">{v.title}</h3>
                  <p className="text-sm font-light text-cream-50/60 leading-relaxed">{v.text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 px-6 text-center">
          <h2 className="font-display text-3xl font-light text-obsidian mb-6">
            Experience the Dalmare Difference
          </h2>
          <Link href="/shop" className="btn-primary">
            Explore the Collection
          </Link>
        </section>
      </main>
      <Footer />
    </>
  );
}
