import { prisma } from "@/lib/prisma";
import { formatPrice } from "@/lib/utils";
import Link from "next/link";
import { Package, ShoppingBag, Users, TrendingUp, ArrowRight, ArrowUp, ArrowDown } from "lucide-react";

export default async function AdminDashboardPage() {
  const [
    totalOrders,
    totalRevenue,
    totalProducts,
    totalCustomers,
    recentOrders,
    lowStockProducts,
  ] = await Promise.all([
    prisma.order.count({ where: { paymentStatus: "PAID" } }),
    prisma.order.aggregate({
      where: { paymentStatus: "PAID" },
      _sum: { total: true },
    }),
    prisma.product.count({ where: { active: true } }),
    prisma.user.count({ where: { role: "CUSTOMER" } }),
    prisma.order.findMany({
      where: { paymentStatus: "PAID" },
      orderBy: { createdAt: "desc" },
      take: 8,
      include: { items: { take: 1 } },
    }),
    prisma.product.findMany({
      where: { stock: { lte: 5 }, active: true },
      take: 5,
      orderBy: { stock: "asc" },
    }),
  ]);

  const stats = [
    {
      label: "Total Revenue",
      value: formatPrice(parseFloat(totalRevenue._sum.total?.toString() || "0")),
      icon: TrendingUp,
      change: "+12%",
      up: true,
    },
    {
      label: "Total Orders",
      value: totalOrders,
      icon: ShoppingBag,
      change: "+8%",
      up: true,
    },
    {
      label: "Products",
      value: totalProducts,
      icon: Package,
      change: null,
      up: true,
    },
    {
      label: "Customers",
      value: totalCustomers,
      icon: Users,
      change: "+5%",
      up: true,
    },
  ];

  const statusColors: Record<string, string> = {
    PENDING: "text-yellow-600 bg-yellow-50",
    CONFIRMED: "text-blue-600 bg-blue-50",
    PROCESSING: "text-indigo-600 bg-indigo-50",
    SHIPPED: "text-purple-600 bg-purple-50",
    DELIVERED: "text-green-600 bg-green-50",
    CANCELLED: "text-red-600 bg-red-50",
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-3xl font-light text-obsidian">Dashboard</h1>
        <p className="text-sm font-light text-stone-dark mt-1">
          Welcome back. Here's what's happening with your store.
        </p>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="bg-cream-50 border border-stone/30 p-5">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-[10px] tracking-[0.15em] uppercase text-stone-dark">{stat.label}</p>
                  <p className="font-display text-2xl font-light text-obsidian mt-1">{stat.value}</p>
                </div>
                <div className="w-10 h-10 bg-champagne/10 flex items-center justify-center">
                  <Icon size={18} className="text-champagne" strokeWidth={1.5} />
                </div>
              </div>
              {stat.change && (
                <div className="flex items-center gap-1 mt-3">
                  {stat.up ? (
                    <ArrowUp size={10} className="text-green-500" />
                  ) : (
                    <ArrowDown size={10} className="text-red-500" />
                  )}
                  <span className={`text-[10px] font-light ${stat.up ? "text-green-600" : "text-red-500"}`}>
                    {stat.change} vs last month
                  </span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent orders */}
        <div className="lg:col-span-2 bg-cream-50 border border-stone/30">
          <div className="flex items-center justify-between px-5 py-4 border-b border-stone/20">
            <h2 className="text-xs tracking-[0.2em] uppercase font-medium text-obsidian">
              Recent Orders
            </h2>
            <Link href="/admin/orders" className="text-xs text-champagne hover:text-champagne-dark flex items-center gap-1">
              View All <ArrowRight size={12} />
            </Link>
          </div>
          <div className="divide-y divide-stone/15">
            {recentOrders.map((order) => (
              <Link
                key={order.id}
                href={`/admin/orders/${order.id}`}
                className="flex items-center justify-between px-5 py-3.5 hover:bg-stone/10 transition-colors"
              >
                <div>
                  <p className="text-xs font-mono text-obsidian">{order.orderNumber}</p>
                  <p className="text-[10px] text-stone-dark mt-0.5">
                    {order.email} · {new Date(order.createdAt).toLocaleDateString("de-AT")}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span
                    className={`text-[9px] px-2 py-0.5 uppercase tracking-[0.1em] font-medium ${
                      statusColors[order.status] || "bg-stone text-obsidian"
                    }`}
                  >
                    {order.status}
                  </span>
                  <span className="text-xs font-light text-obsidian min-w-[70px] text-right">
                    {formatPrice(parseFloat(order.total.toString()))}
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Low stock */}
        <div className="bg-cream-50 border border-stone/30">
          <div className="flex items-center justify-between px-5 py-4 border-b border-stone/20">
            <h2 className="text-xs tracking-[0.2em] uppercase font-medium text-obsidian">
              Low Stock
            </h2>
            <Link href="/admin/products" className="text-xs text-champagne hover:text-champagne-dark flex items-center gap-1">
              Manage <ArrowRight size={12} />
            </Link>
          </div>
          {lowStockProducts.length === 0 ? (
            <div className="px-5 py-8 text-center">
              <p className="text-sm font-light text-stone-dark">All products well stocked</p>
            </div>
          ) : (
            <div className="divide-y divide-stone/15">
              {lowStockProducts.map((p) => (
                <Link
                  key={p.id}
                  href={`/admin/products/${p.id}`}
                  className="flex items-center justify-between px-5 py-3.5 hover:bg-stone/10 transition-colors"
                >
                  <p className="text-xs font-light text-obsidian line-clamp-1 flex-1">{p.name}</p>
                  <span
                    className={`ml-3 text-[9px] font-medium px-2 py-0.5 ${
                      p.stock === 0
                        ? "bg-red-100 text-red-700"
                        : "bg-amber-100 text-amber-700"
                    }`}
                  >
                    {p.stock === 0 ? "OUT" : `${p.stock} left`}
                  </span>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
