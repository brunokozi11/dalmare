import { redirect } from "next/navigation";
import { auth } from "@/lib/auth";
import Link from "next/link";
import {
  LayoutDashboard, Package, ShoppingBag, Users,
  BarChart3, Tag, Mail, LogOut, Settings
} from "lucide-react";

const adminNav = [
  { label: "Dashboard", href: "/admin/dashboard", icon: LayoutDashboard },
  { label: "Products", href: "/admin/products", icon: Package },
  { label: "Orders", href: "/admin/orders", icon: ShoppingBag },
  { label: "Customers", href: "/admin/customers", icon: Users },
  { label: "Analytics", href: "/admin/analytics", icon: BarChart3 },
  { label: "Coupons", href: "/admin/coupons", icon: Tag },
  { label: "Newsletter", href: "/admin/newsletter", icon: Mail },
];

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await auth();
  if (!session || (session.user as any)?.role !== "ADMIN") {
    redirect("/login");
  }

  return (
    <div className="min-h-screen bg-stone-light flex">
      {/* Sidebar */}
      <aside className="w-64 bg-obsidian flex flex-col flex-shrink-0 fixed top-0 bottom-0 left-0 z-40">
        <div className="px-6 py-6 border-b border-white/10">
          <Link href="/" className="font-display text-xl tracking-[0.3em] uppercase text-cream-50">
            Dalmare
          </Link>
          <p className="text-[10px] tracking-[0.2em] uppercase text-champagne mt-0.5">Admin Panel</p>
        </div>

        <nav className="flex-1 py-4 overflow-y-auto">
          {adminNav.map((item) => {
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className="flex items-center gap-3 px-6 py-3 text-xs tracking-[0.12em] uppercase font-light text-cream-50/60 hover:text-cream-50 hover:bg-white/5 transition-colors"
              >
                <Icon size={15} />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="px-6 py-4 border-t border-white/10">
          <p className="text-xs font-light text-cream-50/50 truncate mb-3">{session.user?.name}</p>
          <Link
            href="/"
            className="flex items-center gap-2 text-xs text-cream-50/40 hover:text-cream-50/70 transition-colors"
          >
            <LogOut size={12} />
            Exit Admin
          </Link>
        </div>
      </aside>

      {/* Content */}
      <main className="flex-1 ml-64 p-8 min-h-screen">
        {children}
      </main>
    </div>
  );
}
