import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { formatPrice } from "@/lib/utils";
import { Plus, Edit, Trash2, Eye } from "lucide-react";

export default async function AdminProductsPage({
  searchParams,
}: {
  searchParams: { page?: string };
}) {
  const page = parseInt(searchParams.page || "1");
  const limit = 20;
  const skip = (page - 1) * limit;

  const [products, total] = await Promise.all([
    prisma.product.findMany({
      include: { category: { select: { name: true } } },
      orderBy: { createdAt: "desc" },
      take: limit,
      skip,
    }),
    prisma.product.count(),
  ]);

  const totalPages = Math.ceil(total / limit);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl font-light text-obsidian">Products</h1>
          <p className="text-sm font-light text-stone-dark mt-1">{total} total products</p>
        </div>
        <Link href="/admin/products/new" className="btn-primary flex items-center gap-2">
          <Plus size={14} />
          Add Product
        </Link>
      </div>

      {/* Table */}
      <div className="bg-cream-50 border border-stone/30 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-stone/20 bg-stone/20">
                <th className="text-left px-4 py-3 text-[10px] tracking-[0.15em] uppercase text-stone-dark font-medium">
                  Product
                </th>
                <th className="text-left px-4 py-3 text-[10px] tracking-[0.15em] uppercase text-stone-dark font-medium hidden md:table-cell">
                  Category
                </th>
                <th className="text-left px-4 py-3 text-[10px] tracking-[0.15em] uppercase text-stone-dark font-medium">
                  Price
                </th>
                <th className="text-center px-4 py-3 text-[10px] tracking-[0.15em] uppercase text-stone-dark font-medium">
                  Stock
                </th>
                <th className="text-center px-4 py-3 text-[10px] tracking-[0.15em] uppercase text-stone-dark font-medium hidden md:table-cell">
                  Status
                </th>
                <th className="text-right px-4 py-3 text-[10px] tracking-[0.15em] uppercase text-stone-dark font-medium">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone/15">
              {products.map((product) => (
                <tr key={product.id} className="hover:bg-stone/10 transition-colors">
                  <td className="px-4 py-4">
                    <div className="flex items-center gap-3">
                      {product.images[0] && (
                        <div
                          className="w-10 h-12 bg-stone-light flex-shrink-0"
                          style={{
                            backgroundImage: `url(${product.images[0]})`,
                            backgroundSize: "cover",
                            backgroundPosition: "center",
                          }}
                        />
                      )}
                      <div>
                        <p className="text-xs font-light text-obsidian line-clamp-1">
                          {product.name}
                        </p>
                        {product.sku && (
                          <p className="text-[10px] text-stone-dark font-mono mt-0.5">{product.sku}</p>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-4 hidden md:table-cell">
                    <span className="text-xs font-light text-stone-dark">{product.category.name}</span>
                  </td>
                  <td className="px-4 py-4">
                    <span className="text-xs font-light text-obsidian">
                      {formatPrice(parseFloat(product.price.toString()))}
                    </span>
                  </td>
                  <td className="px-4 py-4 text-center">
                    <span
                      className={`text-[10px] font-medium px-2 py-0.5 ${
                        product.stock === 0
                          ? "bg-red-100 text-red-700"
                          : product.stock <= 5
                          ? "bg-amber-100 text-amber-700"
                          : "bg-green-100 text-green-700"
                      }`}
                    >
                      {product.stock}
                    </span>
                  </td>
                  <td className="px-4 py-4 text-center hidden md:table-cell">
                    <span
                      className={`text-[9px] px-2 py-0.5 uppercase tracking-[0.1em] font-medium ${
                        product.active
                          ? "bg-green-100 text-green-700"
                          : "bg-stone text-stone-dark"
                      }`}
                    >
                      {product.active ? "Active" : "Draft"}
                    </span>
                  </td>
                  <td className="px-4 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Link
                        href={`/product/${product.slug}`}
                        target="_blank"
                        className="p-1.5 text-stone-dark hover:text-obsidian transition-colors"
                        title="View product"
                      >
                        <Eye size={14} />
                      </Link>
                      <Link
                        href={`/admin/products/${product.id}`}
                        className="p-1.5 text-stone-dark hover:text-obsidian transition-colors"
                        title="Edit product"
                      >
                        <Edit size={14} />
                      </Link>
                      <button
                        className="p-1.5 text-red-400 hover:text-red-600 transition-colors"
                        title="Delete product"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-4 border-t border-stone/20">
            <p className="text-xs font-light text-stone-dark">
              Page {page} of {totalPages}
            </p>
            <div className="flex gap-2">
              {page > 1 && (
                <Link
                  href={`?page=${page - 1}`}
                  className="text-xs px-3 py-1.5 border border-stone/40 hover:border-obsidian transition-colors"
                >
                  Previous
                </Link>
              )}
              {page < totalPages && (
                <Link
                  href={`?page=${page + 1}`}
                  className="text-xs px-3 py-1.5 border border-stone/40 hover:border-obsidian transition-colors"
                >
                  Next
                </Link>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
