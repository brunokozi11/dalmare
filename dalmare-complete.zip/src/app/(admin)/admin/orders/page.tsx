import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { formatPrice } from "@/lib/utils";

export default async function AdminOrdersPage({
  searchParams,
}: {
  searchParams: { page?: string; status?: string };
}) {
  const page = parseInt(searchParams.page || "1");
  const limit = 20;
  const skip = (page - 1) * limit;
  const status = searchParams.status;

  const where = status ? { status: status as any } : {};

  const [orders, total] = await Promise.all([
    prisma.order.findMany({
      where,
      orderBy: { createdAt: "desc" },
      take: limit,
      skip,
      include: { items: { select: { quantity: true } } },
    }),
    prisma.order.count({ where }),
  ]);

  const totalPages = Math.ceil(total / limit);

  const statusColors: Record<string, string> = {
    PENDING: "bg-yellow-100 text-yellow-700",
    CONFIRMED: "bg-blue-100 text-blue-700",
    PROCESSING: "bg-indigo-100 text-indigo-700",
    SHIPPED: "bg-purple-100 text-purple-700",
    DELIVERED: "bg-green-100 text-green-700",
    CANCELLED: "bg-red-100 text-red-700",
    REFUNDED: "bg-stone text-stone-dark",
  };

  const allStatuses = ["PENDING", "CONFIRMED", "PROCESSING", "SHIPPED", "DELIVERED", "CANCELLED"];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl font-light text-obsidian">Orders</h1>
        <p className="text-sm font-light text-stone-dark mt-1">{total} total orders</p>
      </div>

      {/* Status filter */}
      <div className="flex gap-2 flex-wrap">
        <Link
          href="/admin/orders"
          className={`text-[10px] uppercase tracking-[0.12em] px-3 py-1.5 border transition-colors ${
            !status ? "border-obsidian bg-obsidian text-cream-50" : "border-stone/40 text-obsidian/70 hover:border-obsidian"
          }`}
        >
          All
        </Link>
        {allStatuses.map((s) => (
          <Link
            key={s}
            href={`/admin/orders?status=${s}`}
            className={`text-[10px] uppercase tracking-[0.12em] px-3 py-1.5 border transition-colors ${
              status === s ? "border-obsidian bg-obsidian text-cream-50" : "border-stone/40 text-obsidian/70 hover:border-obsidian"
            }`}
          >
            {s.toLowerCase()}
          </Link>
        ))}
      </div>

      <div className="bg-cream-50 border border-stone/30 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-stone/20 bg-stone/20">
                {["Order", "Customer", "Date", "Items", "Total", "Status", ""].map((h) => (
                  <th
                    key={h}
                    className={`px-4 py-3 text-[10px] tracking-[0.15em] uppercase text-stone-dark font-medium ${
                      h === "" || h === "Items" || h === "Total" ? "text-right" : "text-left"
                    } ${["Date", "Items"].includes(h) ? "hidden md:table-cell" : ""}`}
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-stone/15">
              {orders.map((order) => (
                <tr key={order.id} className="hover:bg-stone/10 transition-colors">
                  <td className="px-4 py-4">
                    <p className="text-xs font-mono text-obsidian">{order.orderNumber}</p>
                  </td>
                  <td className="px-4 py-4">
                    <p className="text-xs font-light text-obsidian">
                      {order.firstName} {order.lastName}
                    </p>
                    <p className="text-[10px] text-stone-dark">{order.email}</p>
                  </td>
                  <td className="px-4 py-4 hidden md:table-cell">
                    <p className="text-xs font-light text-stone-dark">
                      {new Date(order.createdAt).toLocaleDateString("de-AT")}
                    </p>
                  </td>
                  <td className="px-4 py-4 text-right hidden md:table-cell">
                    <span className="text-xs font-light text-stone-dark">
                      {order.items.reduce((s, i) => s + i.quantity, 0)}
                    </span>
                  </td>
                  <td className="px-4 py-4 text-right">
                    <span className="text-xs font-light text-obsidian">
                      {formatPrice(parseFloat(order.total.toString()))}
                    </span>
                  </td>
                  <td className="px-4 py-4">
                    <span
                      className={`text-[9px] px-2 py-0.5 uppercase tracking-[0.1em] font-medium ${
                        statusColors[order.status] || ""
                      }`}
                    >
                      {order.status}
                    </span>
                  </td>
                  <td className="px-4 py-4 text-right">
                    <Link
                      href={`/admin/orders/${order.id}`}
                      className="text-[10px] uppercase tracking-[0.1em] text-champagne hover:text-champagne-dark"
                    >
                      View
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-4 border-t border-stone/20">
            <p className="text-xs font-light text-stone-dark">Page {page} of {totalPages}</p>
            <div className="flex gap-2">
              {page > 1 && (
                <Link href={`?page=${page - 1}${status ? `&status=${status}` : ""}`}
                  className="text-xs px-3 py-1.5 border border-stone/40 hover:border-obsidian transition-colors">
                  Previous
                </Link>
              )}
              {page < totalPages && (
                <Link href={`?page=${page + 1}${status ? `&status=${status}` : ""}`}
                  className="text-xs px-3 py-1.5 border border-stone/40 hover:border-obsidian transition-colors">
                  Next
                </Link>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
