import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(
  req: NextRequest,
  { params }: { params: { slug: string } }
) {
  try {
    const product = await prisma.product.findUnique({
      where: { slug: params.slug, active: true },
      include: {
        category: true,
        reviews: {
          where: { approved: true },
          include: {
            user: { select: { firstName: true, lastName: true, image: true } },
          },
          orderBy: { createdAt: "desc" },
        },
      },
    });

    if (!product) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 });
    }

    // Fetch related products from same category
    const related = await prisma.product.findMany({
      where: {
        categoryId: product.categoryId,
        id: { not: product.id },
        active: true,
      },
      include: { category: { select: { id: true, name: true, slug: true } } },
      take: 4,
    });

    return NextResponse.json({ product, related });
  } catch (error) {
    console.error("Product by slug error:", error);
    return NextResponse.json({ error: "Failed to fetch product" }, { status: 500 });
  }
}
