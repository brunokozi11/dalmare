import { NextRequest, NextResponse } from "next/server";
import { stripe, formatAmountForStripe } from "@/lib/stripe";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";
import { generateOrderNumber } from "@/lib/utils";

export async function POST(req: NextRequest) {
  try {
    const session = await auth();
    const body = await req.json();
    const { items, email, firstName, lastName, phone, shippingAddress, notes } = body;

    if (!items || items.length === 0) {
      return NextResponse.json({ error: "No items in cart" }, { status: 400 });
    }

    // Validate products and calculate totals
    const productIds = items.map((i: any) => i.productId);
    const products = await prisma.product.findMany({
      where: { id: { in: productIds }, active: true },
    });

    const lineItems = [];
    let subtotal = 0;

    for (const item of items) {
      const product = products.find((p) => p.id === item.productId);
      if (!product) {
        return NextResponse.json({ error: `Product ${item.productId} not found` }, { status: 400 });
      }
      if (product.stock < item.quantity) {
        return NextResponse.json(
          { error: `${product.name} is out of stock` },
          { status: 400 }
        );
      }

      const price = parseFloat(product.price.toString());
      subtotal += price * item.quantity;

      lineItems.push({
        price_data: {
          currency: "eur",
          product_data: {
            name: product.name,
            images: product.images.slice(0, 1),
            metadata: { productId: product.id },
          },
          unit_amount: formatAmountForStripe(price, "eur"),
        },
        quantity: item.quantity,
      });
    }

    // Shipping cost (free over €150)
    const shippingCost = subtotal >= 150 ? 0 : 9.99;
    const total = subtotal + shippingCost;
    const orderNumber = generateOrderNumber();

    // Create pending order
    const order = await prisma.order.create({
      data: {
        orderNumber,
        userId: session?.user?.id || null,
        email,
        firstName,
        lastName,
        phone,
        subtotal,
        shippingCost,
        total,
        notes,
        items: {
          create: items.map((item: any) => {
            const product = products.find((p) => p.id === item.productId)!;
            return {
              productId: item.productId,
              name: product.name,
              image: product.images[0] || null,
              quantity: item.quantity,
              price: parseFloat(product.price.toString()),
            };
          }),
        },
        shippingAddress: {
          create: { ...shippingAddress, type: "shipping" },
        },
      },
    });

    // Create Stripe checkout session
    const stripeSession = await stripe.checkout.sessions.create({
      mode: "payment",
      payment_method_types: ["card", "paypal"],
      line_items: lineItems,
      ...(shippingCost > 0 && {
        shipping_options: [
          {
            shipping_rate_data: {
              type: "fixed_amount",
              fixed_amount: {
                amount: formatAmountForStripe(shippingCost, "eur"),
                currency: "eur",
              },
              display_name: "Standard Shipping",
              delivery_estimate: {
                minimum: { unit: "business_day", value: 5 },
                maximum: { unit: "business_day", value: 10 },
              },
            },
          },
        ],
      }),
      customer_email: email,
      metadata: {
        orderId: order.id,
        orderNumber,
      },
      success_url: `${process.env.NEXT_PUBLIC_APP_URL}/checkout/success?session_id={CHECKOUT_SESSION_ID}&order=${orderNumber}`,
      cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/checkout?cancelled=true`,
      expires_at: Math.floor(Date.now() / 1000) + 30 * 60, // 30 minutes
    });

    // Update order with Stripe session ID
    await prisma.order.update({
      where: { id: order.id },
      data: { stripeSessionId: stripeSession.id },
    });

    return NextResponse.json({ sessionId: stripeSession.id, url: stripeSession.url });
  } catch (error) {
    console.error("Checkout session error:", error);
    return NextResponse.json({ error: "Failed to create checkout session" }, { status: 500 });
  }
}
