export type ProductWithCategory = {
  id: string;
  name: string;
  slug: string;
  description: string;
  details: string | null;
  price: string | number;
  comparePrice: string | number | null;
  stock: number;
  images: string[];
  featured: boolean;
  bestSeller: boolean;
  newArrival: boolean;
  active: boolean;
  material: string | null;
  sku: string | null;
  category: {
    id: string;
    name: string;
    slug: string;
  };
};

export type CartItem = {
  id: string;
  productId: string;
  quantity: number;
  product: ProductWithCategory;
};

export type OrderWithItems = {
  id: string;
  orderNumber: string;
  status: string;
  paymentStatus: string;
  subtotal: number | string;
  shippingCost: number | string;
  discount: number | string;
  total: number | string;
  createdAt: Date | string;
  items: Array<{
    id: string;
    name: string;
    image: string | null;
    quantity: number;
    price: number | string;
    product: { slug: string };
  }>;
};

export type UserProfile = {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  role: "CUSTOMER" | "ADMIN";
  image: string | null;
  createdAt: Date | string;
};

export type Address = {
  id: string;
  label: string | null;
  firstName: string;
  lastName: string;
  company: string | null;
  address1: string;
  address2: string | null;
  city: string;
  state: string | null;
  postalCode: string;
  country: string;
  phone: string | null;
  isDefault: boolean;
};

export type Review = {
  id: string;
  rating: number;
  title: string | null;
  body: string | null;
  verified: boolean;
  createdAt: Date | string;
  user: {
    firstName: string;
    lastName: string;
    image: string | null;
  };
};

export type PaginationMeta = {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
};

export type ApiResponse<T> = {
  success: boolean;
  data?: T;
  error?: string;
  meta?: PaginationMeta;
};

export type SortOption = "newest" | "oldest" | "price_asc" | "price_desc" | "name_asc";

export type FilterParams = {
  category?: string;
  minPrice?: number;
  maxPrice?: number;
  sort?: SortOption;
  search?: string;
  page?: number;
  limit?: number;
  featured?: boolean;
};
