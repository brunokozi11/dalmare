"use client";

import { useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { X, Minus, Plus, ShoppingBag } from "lucide-react";
import { useCartStore } from "@/lib/cartStore";
import { formatPrice } from "@/lib/utils";

export function CartDrawer() {
  const { items, isOpen, closeCart, removeItem, updateQuantity, getTotalPrice } = useCartStore();
  const total = getTotalPrice();

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => { document.body.style.overflow = ""; };
  }, [isOpen]);

  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-obsidian/40 backdrop-blur-sm z-50 transition-opacity animate-fade-in"
          onClick={closeCart}
        />
      )}

      {/* Drawer */}
      <div
        className={`fixed right-0 top-0 bottom-0 z-50 w-full max-w-md bg-cream-50 flex flex-col shadow-luxury-lg transition-transform duration-500 ease-out-expo ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-stone/30">
          <div className="flex items-center gap-3">
            <ShoppingBag size={18} className="text-obsidian" />
            <h2 className="font-body text-xs tracking-[0.25em] uppercase font-medium text-obsidian">
              Your Cart ({items.length})
            </h2>
          </div>
          <button
            onClick={closeCart}
            className="text-obsidian/50 hover:text-obsidian transition-colors"
            aria-label="Close cart"
          >
            <X size={18} />
          </button>
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto px-6 py-4">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <ShoppingBag size={48} className="text-stone mb-4" strokeWidth={1} />
              <p className="font-display text-2xl font-light text-obsidian mb-2">Your cart is empty</p>
              <p className="text-sm font-light text-stone-dark mb-8">
                Discover our collection and find your perfect piece.
              </p>
              <button onClick={closeCart} className="btn-primary">
                Explore Collection
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              {items.map((item) => (
                <div key={item.product.id} className="flex gap-4">
                  {/* Image */}
                  <Link
                    href={`/product/${item.product.slug}`}
                    onClick={closeCart}
                    className="flex-shrink-0 w-20 h-24 bg-stone-light overflow-hidden"
                  >
                    {item.product.images?.[0] ? (
                      <Image
                        src={item.product.images[0]}
                        alt={item.product.name}
                        width={80}
                        height={96}
                        className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                      />
                    ) : (
                      <div className="w-full h-full bg-stone" />
                    )}
                  </Link>

                  {/* Details */}
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start gap-2">
                      <Link
                        href={`/product/${item.product.slug}`}
                        onClick={closeCart}
                        className="font-light text-sm text-obsidian hover:text-champagne transition-colors line-clamp-2"
                      >
                        {item.product.name}
                      </Link>
                      <button
                        onClick={() => removeItem(item.product.id)}
                        className="text-stone-dark hover:text-obsidian transition-colors flex-shrink-0 mt-0.5"
                        aria-label="Remove item"
                      >
                        <X size={14} />
                      </button>
                    </div>

                    <p className="text-xs text-stone-dark mt-1 font-light">
                      {item.product.category.name}
                    </p>

                    <div className="flex items-center justify-between mt-3">
                      {/* Quantity */}
                      <div className="flex items-center border border-stone/40">
                        <button
                          onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                          className="w-7 h-7 flex items-center justify-center text-obsidian/60 hover:text-obsidian hover:bg-stone/30 transition-colors"
                          aria-label="Decrease quantity"
                        >
                          <Minus size={12} />
                        </button>
                        <span className="w-8 text-center text-xs font-light">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                          disabled={item.quantity >= item.product.stock}
                          className="w-7 h-7 flex items-center justify-center text-obsidian/60 hover:text-obsidian hover:bg-stone/30 transition-colors disabled:opacity-30"
                          aria-label="Increase quantity"
                        >
                          <Plus size={12} />
                        </button>
                      </div>

                      <span className="font-light text-sm text-obsidian">
                        {formatPrice(parseFloat(item.product.price as string) * item.quantity)}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        {items.length > 0 && (
          <div className="border-t border-stone/30 px-6 py-6 space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-xs tracking-[0.15em] uppercase font-light text-stone-dark">
                Subtotal
              </span>
              <span className="font-light text-obsidian">{formatPrice(total)}</span>
            </div>
            <p className="text-xs font-light text-stone-dark">
              Shipping and taxes calculated at checkout
            </p>
            <Link href="/checkout" onClick={closeCart} className="btn-primary w-full text-center">
              Proceed to Checkout
            </Link>
            <button
              onClick={closeCart}
              className="w-full text-center text-xs font-light tracking-[0.15em] uppercase text-stone-dark hover:text-obsidian transition-colors py-2"
            >
              Continue Shopping
            </button>
          </div>
        )}
      </div>
    </>
  );
}
