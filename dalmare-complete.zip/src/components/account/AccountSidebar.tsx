"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";
import { LayoutDashboard, Package, User, MapPin, Heart, LogOut } from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { label: "Dashboard", href: "/account/dashboard", icon: LayoutDashboard },
  { label: "Orders", href: "/account/orders", icon: Package },
  { label: "Profile", href: "/account/profile", icon: User },
  { label: "Addresses", href: "/account/profile#addresses", icon: MapPin },
  { label: "Wishlist", href: "/account/wishlist", icon: Heart },
];

type Props = {
  user: { name?: string | null; email?: string | null; image?: string | null };
};

export function AccountSidebar({ user }: Props) {
  const pathname = usePathname();

  return (
    <aside className="md:col-span-1">
      {/* User info */}
      <div className="bg-cream-50 border border-stone/30 p-6 mb-4">
        <div className="w-12 h-12 rounded-full bg-champagne/20 flex items-center justify-center mb-3">
          <span className="font-display text-xl text-champagne">
            {user.name?.charAt(0) || "U"}
          </span>
        </div>
        <p className="font-light text-sm text-obsidian">{user.name}</p>
        <p className="text-[11px] text-stone-dark mt-0.5 truncate">{user.email}</p>
      </div>

      {/* Navigation */}
      <nav className="bg-cream-50 border border-stone/30">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = pathname === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 px-5 py-3.5 text-xs tracking-[0.12em] uppercase font-light border-b border-stone/20 last:border-0 transition-colors",
                active
                  ? "bg-obsidian text-cream-50"
                  : "text-obsidian/70 hover:bg-stone/30 hover:text-obsidian"
              )}
            >
              <Icon size={14} />
              {item.label}
            </Link>
          );
        })}
        <button
          onClick={() => signOut({ callbackUrl: "/" })}
          className="w-full flex items-center gap-3 px-5 py-3.5 text-xs tracking-[0.12em] uppercase font-light text-red-500/70 hover:text-red-600 hover:bg-red-50/50 transition-colors"
        >
          <LogOut size={14} />
          Sign Out
        </button>
      </nav>
    </aside>
  );
}
