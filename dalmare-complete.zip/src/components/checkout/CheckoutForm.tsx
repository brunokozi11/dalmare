"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Lock, ChevronDown, ChevronUp } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { useCartStore } from "@/lib/cartStore";
import { formatPrice } from "@/lib/utils";
import { checkoutSchema, type CheckoutInput } from "@/lib/validations";
import { cn } from "@/lib/utils";

const COUNTRIES = [
  { code: "AT", name: "Austria" },
  { code: "DE", name: "Germany" },
  { code: "CH", name: "Switzerland" },
  { code: "FR", name: "France" },
  { code: "IT", name: "Italy" },
  { code: "GB", name: "United Kingdom" },
  { code: "US", name: "United States" },
  { code: "CA", name: "Canada" },
  { code: "AU", name: "Australia" },
  { code: "NL", name: "Netherlands" },
  { code: "BE", name: "Belgium" },
  { code: "ES", name: "Spain" },
];

export function CheckoutForm() {
  const router = useRouter();
  const { data: session } = useSession();
  const { items, getTotalPrice, clearCart } = useCartStore();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [orderOpen, setOrderOpen] = useState(true);
  const [sameBilling, setSameBilling] = useState(true);

  const subtotal = getTotalPrice();
  const shippingCost = subtotal >= 150 ? 0 : 9.99;
  const total = subtotal + shippingCost;

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<CheckoutInput>({
    resolver: zodResolver(checkoutSchema),
    defaultValues: {
      email: session?.user?.email || "",
      sameBillingAddress: true,
    },
  });

  if (items.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-6 py-24 text-center">
        <p className="font-display text-3xl font-light text-obsidian mb-4">Your cart is empty</p>
        <Link href="/shop" className="btn-primary">
          Continue Shopping
        </Link>
      </div>
    );
  }

  const onSubmit = async (data: CheckoutInput) => {
    setLoading(true);
    setError("");

    try {
      const payload = {
        items: items.map((i) => ({ productId: i.product.id, quantity: i.quantity })),
        email: data.email,
        firstName: data.firstName,
        lastName: data.lastName,
        phone: data.phone,
        shippingAddress: data.shippingAddress,
        notes: data.notes,
      };

      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const result = await res.json();

      if (!res.ok) {
        setError(result.error || "Checkout failed");
        return;
      }

      // Redirect to Stripe
      if (result.url) {
        clearCart();
        window.location.href = result.url;
      }
    } catch (err) {
      setError("An unexpected error occurred. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-6 md:px-12 py-10">
      {/* Header */}
      <div className="text-center mb-10">
        <Link href="/" className="font-display text-2xl tracking-[0.35em] uppercase text-obsidian">
          Dalmare
        </Link>
        <div className="flex items-center justify-center gap-3 mt-4 text-[10px] tracking-[0.2em] uppercase text-stone-dark">
          <Link href="/cart" className="hover:text-obsidian transition-colors">Cart</Link>
          <span className="text-champagne">›</span>
          <span className="text-obsidian">Information</span>
          <span className="text-stone-medium">›</span>
          <span className="text-stone-medium">Payment</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
        {/* Form — left */}
        <form
          onSubmit={handleSubmit(onSubmit)}
          className="lg:col-span-3 space-y-8"
        >
          {/* Contact */}
          <section>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xs tracking-[0.25em] uppercase font-medium text-obsidian">
                Contact Information
              </h2>
              {!session && (
                <Link href="/login" className="text-xs font-light text-champagne hover:text-champagne-dark">
                  Sign in
                </Link>
              )}
            </div>
            <div className="space-y-5">
              <div>
                <label className="label-luxury">Email</label>
                <input
                  type="email"
                  {...register("email")}
                  className="input-luxury"
                  placeholder="your@email.com"
                />
                {errors.email && (
                  <p className="text-red-500 text-xs mt-1">{errors.email.message}</p>
                )}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="label-luxury">First Name</label>
                  <input {...register("firstName")} className="input-luxury" placeholder="John" />
                  {errors.firstName && (
                    <p className="text-red-500 text-xs mt-1">{errors.firstName.message}</p>
                  )}
                </div>
                <div>
                  <label className="label-luxury">Last Name</label>
                  <input {...register("lastName")} className="input-luxury" placeholder="Smith" />
                  {errors.lastName && (
                    <p className="text-red-500 text-xs mt-1">{errors.lastName.message}</p>
                  )}
                </div>
              </div>
              <div>
                <label className="label-luxury">Phone (optional)</label>
                <input
                  type="tel"
                  {...register("phone")}
                  className="input-luxury"
                  placeholder="+43 123 456789"
                />
              </div>
            </div>
          </section>

          {/* Shipping address */}
          <section>
            <h2 className="text-xs tracking-[0.25em] uppercase font-medium text-obsidian mb-6">
              Shipping Address
            </h2>
            <AddressFields prefix="shippingAddress" register={register} errors={errors?.shippingAddress} />
          </section>

          {/* Billing address */}
          <section>
            <div className="flex items-center gap-3 mb-4">
              <input
                type="checkbox"
                id="sameBilling"
                checked={sameBilling}
                onChange={(e) => setSameBilling(e.target.checked)}
                className="w-4 h-4 border-stone accent-champagne"
              />
              <label htmlFor="sameBilling" className="text-xs font-light text-obsidian cursor-pointer">
                Billing address same as shipping
              </label>
            </div>
          </section>

          {/* Notes */}
          <section>
            <label className="label-luxury">Order Notes (optional)</label>
            <textarea
              {...register("notes")}
              rows={3}
              className="input-luxury resize-none"
              placeholder="Special instructions, gift messages..."
            />
          </section>

          {error && (
            <div className="bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-600 font-light">
              {error}
            </div>
          )}

          {/* Submit */}
          <div className="flex items-center gap-4">
            <button
              type="submit"
              disabled={loading}
              className="btn-gold flex-1 flex items-center justify-center gap-2"
            >
              <Lock size={14} />
              {loading ? "Processing..." : "Continue to Payment"}
            </button>
          </div>

          <p className="text-[10px] text-stone-dark tracking-[0.1em] text-center">
            You will be redirected to Stripe's secure checkout. Your card details are never stored on our servers.
          </p>
        </form>

        {/* Order summary — right */}
        <aside className="lg:col-span-2">
          <div className="bg-cream-50 border border-stone/30 p-6 sticky top-28">
            <button
              onClick={() => setOrderOpen(!orderOpen)}
              className="w-full flex items-center justify-between mb-4"
            >
              <span className="text-xs tracking-[0.2em] uppercase font-medium text-obsidian">
                Order Summary ({items.length})
              </span>
              {orderOpen ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
            </button>

            {orderOpen && (
              <div className="divide-y divide-stone/20 mb-4">
                {items.map((item) => (
                  <div key={item.product.id} className="flex gap-3 py-4">
                    <div className="relative w-16 h-20 bg-stone-light flex-shrink-0">
                      {item.product.images?.[0] && (
                        <Image
                          src={item.product.images[0]}
                          alt={item.product.name}
                          fill
                          className="object-cover"
                          sizes="64px"
                        />
                      )}
                      <span className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-stone-dark text-white text-[9px] flex items-center justify-center">
                        {item.quantity}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-light text-obsidian line-clamp-2">{item.product.name}</p>
                      <p className="text-[10px] text-stone-dark mt-0.5">{item.product.category.name}</p>
                      <p className="text-xs font-light text-obsidian mt-1">
                        {formatPrice(parseFloat(item.product.price as string) * item.quantity)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="space-y-2 pt-4 border-t border-stone/30">
              <div className="flex justify-between text-xs font-light">
                <span className="text-stone-dark">Subtotal</span>
                <span>{formatPrice(subtotal)}</span>
              </div>
              <div className="flex justify-between text-xs font-light">
                <span className="text-stone-dark">Shipping</span>
                <span>{shippingCost === 0 ? "Free" : formatPrice(shippingCost)}</span>
              </div>
              <div className="flex justify-between text-sm font-light pt-2 border-t border-stone/30">
                <span className="text-obsidian">Total</span>
                <span className="text-champagne font-medium">{formatPrice(total)}</span>
              </div>
            </div>

            {subtotal >= 150 && (
              <p className="text-[10px] tracking-[0.1em] text-green-600 uppercase mt-3">
                ✓ Free shipping applied
              </p>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
}

function AddressFields({
  prefix,
  register,
  errors,
}: {
  prefix: string;
  register: any;
  errors: any;
}) {
  return (
    <div className="space-y-5">
      <div>
        <label className="label-luxury">Address</label>
        <input
          {...register(`${prefix}.address1`)}
          className="input-luxury"
          placeholder="123 Main Street"
        />
        {errors?.address1 && (
          <p className="text-red-500 text-xs mt-1">{errors.address1.message}</p>
        )}
      </div>
      <div>
        <label className="label-luxury">Apartment, suite, etc. (optional)</label>
        <input
          {...register(`${prefix}.address2`)}
          className="input-luxury"
          placeholder="Apt 4B"
        />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="label-luxury">City</label>
          <input
            {...register(`${prefix}.city`)}
            className="input-luxury"
            placeholder="Vienna"
          />
          {errors?.city && (
            <p className="text-red-500 text-xs mt-1">{errors.city.message}</p>
          )}
        </div>
        <div>
          <label className="label-luxury">Postal Code</label>
          <input
            {...register(`${prefix}.postalCode`)}
            className="input-luxury"
            placeholder="1010"
          />
          {errors?.postalCode && (
            <p className="text-red-500 text-xs mt-1">{errors.postalCode.message}</p>
          )}
        </div>
      </div>
      <div>
        <label className="label-luxury">Country</label>
        <select
          {...register(`${prefix}.country`)}
          className="input-luxury bg-transparent"
        >
          <option value="">Select country</option>
          {COUNTRIES.map((c) => (
            <option key={c.code} value={c.code}>
              {c.name}
            </option>
          ))}
        </select>
        {errors?.country && (
          <p className="text-red-500 text-xs mt-1">{errors.country.message}</p>
        )}
      </div>
    </div>
  );
}
