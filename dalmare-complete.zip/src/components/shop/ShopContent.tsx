"use client";

import { useState, useEffect, useCallback } from "react";
import { useRouter, usePathname } from "next/navigation";
import { SlidersHorizontal, ChevronDown, X, Search } from "lucide-react";
import { ProductCard } from "@/components/shop/ProductCard";
import type { ProductWithCategory } from "@/types";
import { cn } from "@/lib/utils";

type Props = {
  searchParams: { [key: string]: string | undefined };
};

const SORT_OPTIONS = [
  { value: "newest", label: "Newest First" },
  { value: "oldest", label: "Oldest First" },
  { value: "price_asc", label: "Price: Low to High" },
  { value: "price_desc", label: "Price: High to Low" },
  { value: "name_asc", label: "Name A–Z" },
];

export function ShopContent({ searchParams }: Props) {
  const router = useRouter();
  const pathname = usePathname();
  const [products, setProducts] = useState<ProductWithCategory[]>([]);
  const [categories, setCategories] = useState<{ id: string; name: string; slug: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const { category, sort = "newest", search, filter, page = "1" } = searchParams;

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (category) params.set("category", category);
      if (sort) params.set("sort", sort);
      if (search) params.set("search", search);
      if (filter) params.set("filter", filter);
      params.set("page", page);

      const res = await fetch(`/api/products?${params}`);
      const data = await res.json();
      setProducts(data.products || []);
      setTotal(data.total || 0);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [category, sort, search, filter, page]);

  const fetchCategories = useCallback(async () => {
    try {
      const res = await fetch("/api/products/categories");
      const data = await res.json();
      setCategories(data.categories || []);
    } catch {}
  }, []);

  useEffect(() => {
    fetchProducts();
    fetchCategories();
  }, [fetchProducts, fetchCategories]);

  const updateParam = (key: string, value: string | null) => {
    const params = new URLSearchParams(
      Object.entries(searchParams).filter(([, v]) => v !== undefined) as [string, string][]
    );
    if (value) {
      params.set(key, value);
    } else {
      params.delete(key);
    }
    params.delete("page");
    router.push(`${pathname}?${params.toString()}`);
  };

  const clearFilters = () => router.push(pathname);

  const hasActiveFilters = !!(category || search || filter);

  return (
    <div className="max-w-7xl mx-auto px-6 md:px-12 py-10">
      {/* Page header */}
      <div className="mb-10">
        <h1 className="font-display text-4xl md:text-5xl font-light text-obsidian mb-2">
          {category
            ? categories.find((c) => c.slug === category)?.name || "Collection"
            : filter === "new"
            ? "New Arrivals"
            : filter === "bestsellers"
            ? "Best Sellers"
            : filter === "sale"
            ? "Sale"
            : "All Products"}
        </h1>
        {search && (
          <p className="text-sm font-light text-stone-dark mt-2">
            Results for "{search}" — {total} product{total !== 1 ? "s" : ""}
          </p>
        )}
        {!search && (
          <p className="text-sm font-light text-stone-dark mt-2">{total} products</p>
        )}
      </div>

      {/* Toolbar */}
      <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between pb-6 border-b border-stone/30 mb-8">
        {/* Filters left */}
        <div className="flex items-center gap-4 flex-wrap">
          <button
            onClick={() => setFiltersOpen(!filtersOpen)}
            className="flex items-center gap-2 text-xs tracking-[0.15em] uppercase font-light text-obsidian border border-stone/40 px-4 py-2 hover:border-obsidian transition-colors"
          >
            <SlidersHorizontal size={14} />
            Filters
          </button>

          {/* Category pills */}
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => updateParam("category", category === cat.slug ? null : cat.slug)}
              className={cn(
                "text-xs tracking-[0.12em] uppercase font-light px-3 py-1.5 border transition-colors",
                category === cat.slug
                  ? "border-obsidian bg-obsidian text-cream-50"
                  : "border-stone/40 text-obsidian/70 hover:border-obsidian hover:text-obsidian"
              )}
            >
              {cat.name}
            </button>
          ))}

          {hasActiveFilters && (
            <button
              onClick={clearFilters}
              className="flex items-center gap-1 text-xs font-light text-stone-dark hover:text-obsidian transition-colors"
            >
              <X size={12} />
              Clear
            </button>
          )}
        </div>

        {/* Sort right */}
        <div className="relative">
          <select
            value={sort}
            onChange={(e) => updateParam("sort", e.target.value)}
            className="appearance-none bg-transparent border border-stone/40 px-4 py-2 pr-8 text-xs tracking-[0.12em] uppercase font-light text-obsidian cursor-pointer focus:outline-none focus:border-obsidian transition-colors"
          >
            {SORT_OPTIONS.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
          <ChevronDown
            size={12}
            className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-obsidian/50"
          />
        </div>
      </div>

      {/* Products grid */}
      {loading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 md:gap-8">
          {Array(8).fill(0).map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="aspect-product bg-stone rounded-none" />
              <div className="mt-4 space-y-2">
                <div className="h-2 bg-stone rounded w-1/3" />
                <div className="h-3 bg-stone rounded w-2/3" />
                <div className="h-3 bg-stone rounded w-1/4" />
              </div>
            </div>
          ))}
        </div>
      ) : products.length === 0 ? (
        <div className="py-24 text-center">
          <Search size={48} className="text-stone mx-auto mb-4" strokeWidth={1} />
          <p className="font-display text-2xl font-light text-obsidian mb-2">No products found</p>
          <p className="text-sm font-light text-stone-dark mb-8">
            Try adjusting your filters or search terms.
          </p>
          <button onClick={clearFilters} className="btn-secondary">
            Clear Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 md:gap-8">
          {products.map((product, i) => (
            <ProductCard key={product.id} product={product} priority={i < 4} />
          ))}
        </div>
      )}
    </div>
  );
}
