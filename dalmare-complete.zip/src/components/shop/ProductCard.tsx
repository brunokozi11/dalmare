"use client";

import Link from "next/link";
import Image from "next/image";
import { useState } from "react";
import { Heart, ShoppingBag } from "lucide-react";
import { useCartStore } from "@/lib/cartStore";
import { formatPrice, calculateDiscount } from "@/lib/utils";
import { cn } from "@/lib/utils";
import type { ProductWithCategory } from "@/types";

type Props = {
  product: ProductWithCategory;
  className?: string;
  priority?: boolean;
};

export function ProductCard({ product, className, priority = false }: Props) {
  const { addItem } = useCartStore();
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [imageIndex, setImageIndex] = useState(0);
  const discount = calculateDiscount(
    parseFloat(product.price as string),
    product.comparePrice ? parseFloat(product.comparePrice as string) : undefined
  );

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addItem(product);
  };

  const handleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsWishlisted(!isWishlisted);
  };

  return (
    <Link href={`/product/${product.slug}`} className={cn("product-card block", className)}>
      {/* Image */}
      <div
        className="product-image-wrapper"
        onMouseEnter={() => product.images.length > 1 && setImageIndex(1)}
        onMouseLeave={() => setImageIndex(0)}
      >
        {product.images?.[imageIndex] ? (
          <Image
            src={product.images[imageIndex]}
            alt={product.name}
            fill
            sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
            className="product-image"
            priority={priority}
          />
        ) : (
          <div className="absolute inset-0 bg-stone flex items-center justify-center">
            <ShoppingBag size={32} className="text-stone-medium" strokeWidth={1} />
          </div>
        )}

        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5">
          {product.newArrival && <span className="badge-obsidian">New</span>}
          {product.bestSeller && <span className="badge-gold">Best Seller</span>}
          {discount > 0 && <span className="badge-sale">-{discount}%</span>}
          {product.stock === 0 && (
            <span className="badge bg-stone-medium text-white">Sold Out</span>
          )}
        </div>

        {/* Wishlist button */}
        <button
          onClick={handleWishlist}
          className={cn(
            "absolute top-3 right-3 w-8 h-8 flex items-center justify-center bg-cream-50/80 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-all duration-300 hover:bg-cream-50",
            isWishlisted && "opacity-100"
          )}
          aria-label="Add to wishlist"
        >
          <Heart
            size={14}
            className={cn(
              "transition-colors duration-200",
              isWishlisted ? "fill-champagne text-champagne" : "text-obsidian"
            )}
          />
        </button>

        {/* Quick add button */}
        {product.stock > 0 && (
          <button
            onClick={handleAddToCart}
            className="absolute bottom-0 left-0 right-0 bg-obsidian/90 text-cream-50 py-3 text-[10px] tracking-[0.25em] uppercase font-light translate-y-full group-hover:translate-y-0 transition-transform duration-300 hover:bg-obsidian"
          >
            Add to Cart
          </button>
        )}
      </div>

      {/* Info */}
      <div className="mt-4 px-0.5">
        <p className="text-[10px] tracking-[0.2em] uppercase text-stone-dark font-light mb-1">
          {product.category.name}
        </p>
        <h3 className="text-sm font-light text-obsidian group-hover:text-champagne transition-colors duration-200 line-clamp-2">
          {product.name}
        </h3>
        <div className="flex items-center gap-2 mt-2">
          <span className="text-sm font-light text-obsidian">
            {formatPrice(parseFloat(product.price as string))}
          </span>
          {product.comparePrice && (
            <span className="text-xs font-light text-stone-dark line-through">
              {formatPrice(parseFloat(product.comparePrice as string))}
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}
