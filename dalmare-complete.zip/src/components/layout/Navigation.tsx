"use client";

import { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useSession, signOut } from "next-auth/react";
import { ShoppingBag, User, Search, Menu, X, Heart, ChevronDown } from "lucide-react";
import { useCartStore } from "@/lib/cartStore";
import { cn } from "@/lib/utils";

const navLinks = [
  { label: "Collection", href: "/shop" },
  {
    label: "Watches",
    href: "/shop?category=watches",
    children: [
      { label: "Automatic", href: "/shop?category=watches&type=automatic" },
      { label: "Quartz", href: "/shop?category=watches&type=quartz" },
      { label: "Dress Watches", href: "/shop?category=watches&type=dress" },
    ],
  },
  {
    label: "Jewellery",
    href: "/shop?category=jewellery",
    children: [
      { label: "Necklaces", href: "/shop?category=jewellery&type=necklaces" },
      { label: "Bracelets", href: "/shop?category=jewellery&type=bracelets" },
      { label: "Rings", href: "/shop?category=jewellery&type=rings" },
    ],
  },
  { label: "About", href: "/about" },
  { label: "Contact", href: "/contact" },
];

export function Navigation() {
  const pathname = usePathname();
  const { data: session } = useSession();
  const { getTotalItems, openCart } = useCartStore();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const searchRef = useRef<HTMLInputElement>(null);
  const totalItems = getTotalItems();

  const isHomePage = pathname === "/";
  const isTransparent = isHomePage && !scrolled;

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    if (searchOpen) searchRef.current?.focus();
  }, [searchOpen]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      window.location.href = `/shop?search=${encodeURIComponent(searchQuery)}`;
      setSearchOpen(false);
      setSearchQuery("");
    }
  };

  return (
    <>
      <header
        className={cn(
          "fixed top-0 left-0 right-0 z-50 transition-all duration-500",
          isTransparent
            ? "bg-transparent"
            : "bg-cream-50/95 backdrop-blur-sm border-b border-stone/30 shadow-sm"
        )}
      >
        {/* Announcement bar */}
        <div
          className={cn(
            "text-center py-2 text-[10px] tracking-[0.3em] uppercase font-light transition-colors duration-500",
            isTransparent ? "bg-white/10 text-white" : "bg-obsidian text-cream-50"
          )}
        >
          Free worldwide shipping on orders over €150
        </div>

        <div className="flex items-center justify-between px-6 md:px-12 h-16">
          {/* Mobile menu button */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className={cn(
              "md:hidden transition-colors duration-200",
              isTransparent ? "text-white" : "text-obsidian"
            )}
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>

          {/* Desktop Nav left */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.slice(0, 3).map((link) => (
              <div
                key={link.href}
                className="relative group"
                onMouseEnter={() => link.children && setActiveDropdown(link.label)}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                <Link
                  href={link.href}
                  className={cn(
                    "nav-link flex items-center gap-1",
                    isTransparent ? "text-white/80 hover:text-white" : "",
                    pathname === link.href ? "text-champagne" : ""
                  )}
                >
                  {link.label}
                  {link.children && <ChevronDown size={12} className="opacity-60" />}
                </Link>

                {link.children && activeDropdown === link.label && (
                  <div className="absolute top-full left-0 mt-2 w-52 bg-cream-50 border border-stone/30 shadow-luxury py-2 animate-fade-in">
                    {link.children.map((child) => (
                      <Link
                        key={child.href}
                        href={child.href}
                        className="block px-5 py-2.5 text-xs tracking-[0.15em] uppercase font-light text-obsidian/70 hover:text-obsidian hover:bg-stone/20 transition-colors"
                      >
                        {child.label}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </nav>

          {/* Logo center */}
          <Link href="/" className="absolute left-1/2 -translate-x-1/2">
            <span
              className={cn(
                "font-display text-2xl font-light tracking-[0.35em] uppercase transition-colors duration-500",
                isTransparent ? "text-white" : "text-obsidian"
              )}
            >
              Dalmare
            </span>
          </Link>

          {/* Desktop Nav right */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.slice(3).map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  "nav-link",
                  isTransparent ? "text-white/80 hover:text-white" : "",
                  pathname === link.href ? "text-champagne" : ""
                )}
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-4">
            {/* Search */}
            <button
              onClick={() => setSearchOpen(!searchOpen)}
              className={cn(
                "transition-colors duration-200",
                isTransparent ? "text-white/80 hover:text-white" : "text-obsidian/70 hover:text-obsidian"
              )}
              aria-label="Search"
            >
              <Search size={18} />
            </button>

            {/* Account */}
            <Link
              href={session ? "/account/dashboard" : "/login"}
              className={cn(
                "hidden md:block transition-colors duration-200",
                isTransparent ? "text-white/80 hover:text-white" : "text-obsidian/70 hover:text-obsidian"
              )}
              aria-label="Account"
            >
              <User size={18} />
            </Link>

            {/* Wishlist */}
            {session && (
              <Link
                href="/account/wishlist"
                className={cn(
                  "hidden md:block transition-colors duration-200",
                  isTransparent ? "text-white/80 hover:text-white" : "text-obsidian/70 hover:text-obsidian"
                )}
                aria-label="Wishlist"
              >
                <Heart size={18} />
              </Link>
            )}

            {/* Cart */}
            <button
              onClick={openCart}
              className={cn(
                "relative transition-colors duration-200",
                isTransparent ? "text-white/80 hover:text-white" : "text-obsidian/70 hover:text-obsidian"
              )}
              aria-label="Cart"
            >
              <ShoppingBag size={18} />
              {totalItems > 0 && (
                <span className="cart-badge">{totalItems > 9 ? "9+" : totalItems}</span>
              )}
            </button>
          </div>
        </div>

        {/* Search overlay */}
        {searchOpen && (
          <div className="bg-cream-50 border-t border-stone/30 px-6 md:px-12 py-4 animate-fade-in">
            <form onSubmit={handleSearch} className="max-w-xl mx-auto flex items-center gap-4">
              <Search size={16} className="text-stone-dark flex-shrink-0" />
              <input
                ref={searchRef}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search for watches, jewellery..."
                className="flex-1 bg-transparent border-0 text-sm font-light text-obsidian placeholder-stone-dark/60 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setSearchOpen(false)}
                className="text-stone-dark hover:text-obsidian transition-colors"
              >
                <X size={16} />
              </button>
            </form>
          </div>
        )}
      </header>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 bg-cream-50 flex flex-col pt-28 px-8 pb-8 animate-fade-in">
          <nav className="flex flex-col gap-1">
            {navLinks.map((link) => (
              <div key={link.href}>
                <Link
                  href={link.href}
                  onClick={() => setMobileOpen(false)}
                  className="block py-4 text-sm font-light tracking-[0.2em] uppercase text-obsidian border-b border-stone/30"
                >
                  {link.label}
                </Link>
                {link.children && (
                  <div className="pl-4 bg-stone/10">
                    {link.children.map((child) => (
                      <Link
                        key={child.href}
                        href={child.href}
                        onClick={() => setMobileOpen(false)}
                        className="block py-3 text-xs tracking-[0.15em] uppercase text-obsidian/60 border-b border-stone/20"
                      >
                        {child.label}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </nav>

          <div className="mt-auto flex flex-col gap-3">
            <Link
              href={session ? "/account/dashboard" : "/login"}
              onClick={() => setMobileOpen(false)}
              className="btn-secondary text-center"
            >
              {session ? "My Account" : "Sign In"}
            </Link>
            {session && (
              <button
                onClick={() => { signOut(); setMobileOpen(false); }}
                className="text-xs tracking-[0.15em] uppercase text-stone-dark text-center py-2"
              >
                Sign Out
              </button>
            )}
          </div>
        </div>
      )}
    </>
  );
}
