import Link from "next/link";
import { Instagram, Facebook, Youtube } from "lucide-react";

const footerLinks = {
  Shop: [
    { label: "All Products", href: "/shop" },
    { label: "Watches", href: "/shop?category=watches" },
    { label: "Jewellery", href: "/shop?category=jewellery" },
    { label: "New Arrivals", href: "/shop?filter=new" },
    { label: "Best Sellers", href: "/shop?filter=bestsellers" },
  ],
  Help: [
    { label: "Contact Us", href: "/contact" },
    { label: "Shipping Policy", href: "/shipping-policy" },
    { label: "Returns & Refunds", href: "/refund-policy" },
    { label: "FAQ", href: "/contact#faq" },
    { label: "Track Your Order", href: "/account/orders" },
  ],
  Company: [
    { label: "About Dalmare", href: "/about" },
    { label: "Our Story", href: "/about#story" },
    { label: "Sustainability", href: "/about#sustainability" },
    { label: "Press", href: "/contact" },
  ],
  Legal: [
    { label: "Privacy Policy", href: "/privacy-policy" },
    { label: "Terms & Conditions", href: "/terms" },
    { label: "Cookie Policy", href: "/cookie-policy" },
    { label: "Impressum", href: "/impressum" },
  ],
};

export function Footer() {
  return (
    <footer className="bg-obsidian text-cream-50/80">
      {/* Newsletter section */}
      <div className="border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 md:px-12 py-16 text-center">
          <p className="text-xs tracking-[0.3em] uppercase text-champagne mb-4">Newsletter</p>
          <h2 className="font-display text-3xl md:text-4xl font-light text-cream-50 mb-4">
            Be the first to know
          </h2>
          <p className="text-sm font-light text-cream-50/60 mb-8 max-w-sm mx-auto">
            New collections, exclusive offers, and stories from our atelier — delivered to your inbox.
          </p>
          <form
            className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto"
            onSubmit={(e) => {
              e.preventDefault();
              // handled by API
            }}
          >
            <input
              type="email"
              placeholder="Your email address"
              required
              className="flex-1 bg-white/10 border border-white/20 text-cream-50 placeholder-cream-50/40 px-4 py-3 text-sm font-light focus:outline-none focus:border-champagne transition-colors"
            />
            <button type="submit" className="btn-gold whitespace-nowrap">
              Subscribe
            </button>
          </form>
          <p className="text-[10px] tracking-[0.1em] text-cream-50/30 mt-4">
            By subscribing, you agree to our Privacy Policy. Unsubscribe anytime.
          </p>
        </div>
      </div>

      {/* Main footer */}
      <div className="max-w-7xl mx-auto px-6 md:px-12 py-16">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 md:gap-12">
          {/* Brand column */}
          <div className="col-span-2 md:col-span-1">
            <Link href="/" className="font-display text-xl tracking-[0.35em] uppercase text-cream-50">
              Dalmare
            </Link>
            <p className="text-xs font-light text-cream-50/50 mt-4 leading-relaxed max-w-[200px]">
              Timeless elegance crafted for those who appreciate the extraordinary.
            </p>
            <div className="flex items-center gap-4 mt-6">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-cream-50/50 hover:text-champagne transition-colors"
                aria-label="Instagram"
              >
                <Instagram size={16} />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-cream-50/50 hover:text-champagne transition-colors"
                aria-label="Facebook"
              >
                <Facebook size={16} />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-cream-50/50 hover:text-champagne transition-colors"
                aria-label="YouTube"
              >
                <Youtube size={16} />
              </a>
            </div>
          </div>

          {/* Links */}
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h3 className="text-xs tracking-[0.2em] uppercase text-cream-50/40 font-medium mb-4">
                {category}
              </h3>
              <ul className="space-y-2.5">
                {links.map((link) => (
                  <li key={link.href}>
                    <Link
                      href={link.href}
                      className="text-xs font-light text-cream-50/60 hover:text-cream-50 transition-colors"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-6 md:px-12 py-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-[10px] tracking-[0.15em] text-cream-50/30 uppercase">
            © {new Date().getFullYear()} Dalmare. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            {["Visa", "Mastercard", "Amex", "PayPal", "Apple Pay"].map((method) => (
              <span
                key={method}
                className="text-[10px] tracking-[0.1em] text-cream-50/25"
              >
                {method}
              </span>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
