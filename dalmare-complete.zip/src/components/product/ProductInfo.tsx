"use client";

import { useState } from "react";
import Link from "next/link";
import { Minus, Plus, ShoppingBag, Heart, Share2, Shield, Truck, RefreshCw, Star } from "lucide-react";
import { useCartStore } from "@/lib/cartStore";
import { formatPrice, calculateDiscount } from "@/lib/utils";
import type { ProductWithCategory, Review } from "@/types";

type Props = {
  product: ProductWithCategory;
  reviews: Review[];
};

export function ProductInfo({ product, reviews }: Props) {
  const { addItem, openCart } = useCartStore();
  const [quantity, setQuantity] = useState(1);
  const [wishlisted, setWishlisted] = useState(false);
  const [activeTab, setActiveTab] = useState<"description" | "details" | "reviews">("description");
  const [addedToCart, setAddedToCart] = useState(false);

  const price = parseFloat(product.price as string);
  const comparePrice = product.comparePrice ? parseFloat(product.comparePrice as string) : null;
  const discount = calculateDiscount(price, comparePrice || undefined);
  const inStock = product.stock > 0;
  const lowStock = product.stock > 0 && product.stock <= 5;

  const avgRating =
    reviews.length > 0
      ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length
      : null;

  const handleAddToCart = () => {
    addItem(product, quantity);
    setAddedToCart(true);
    openCart();
    setTimeout(() => setAddedToCart(false), 2500);
  };

  const tabs = ["description", "details", "reviews"] as const;

  return (
    <div className="space-y-6">
      {/* Category & badges */}
      <div className="flex items-center gap-3">
        <Link
          href={`/shop?category=${product.category.slug}`}
          className="text-[10px] tracking-[0.25em] uppercase text-stone-dark hover:text-champagne transition-colors"
        >
          {product.category.name}
        </Link>
        {product.newArrival && <span className="badge-obsidian">New</span>}
        {product.bestSeller && <span className="badge-gold">Best Seller</span>}
      </div>

      {/* Name */}
      <h1 className="font-display text-3xl md:text-4xl font-light text-obsidian leading-tight">
        {product.name}
      </h1>

      {/* Rating */}
      {avgRating !== null && (
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-0.5">
            {[1, 2, 3, 4, 5].map((star) => (
              <Star
                key={star}
                size={12}
                className={
                  star <= Math.round(avgRating)
                    ? "fill-champagne text-champagne"
                    : "text-stone"
                }
              />
            ))}
          </div>
          <span className="text-xs font-light text-stone-dark">
            {avgRating.toFixed(1)} ({reviews.length} review{reviews.length !== 1 ? "s" : ""})
          </span>
        </div>
      )}

      {/* Price */}
      <div className="flex items-center gap-3 py-4 border-y border-stone/30">
        <span className="font-display text-3xl font-light text-obsidian">
          {formatPrice(price)}
        </span>
        {comparePrice && (
          <>
            <span className="text-base font-light text-stone-dark line-through">
              {formatPrice(comparePrice)}
            </span>
            <span className="badge-sale">-{discount}%</span>
          </>
        )}
      </div>

      {/* Stock status */}
      <div>
        {!inStock ? (
          <p className="text-sm font-light text-red-500">Out of stock</p>
        ) : lowStock ? (
          <p className="text-sm font-light text-amber-600">
            Only {product.stock} left in stock
          </p>
        ) : (
          <p className="text-sm font-light text-green-600">In stock — ready to ship</p>
        )}
      </div>

      {/* Material */}
      {product.material && (
        <p className="text-sm font-light text-stone-dark">
          <span className="text-[10px] tracking-[0.15em] uppercase text-obsidian/50 mr-2">Material</span>
          {product.material}
        </p>
      )}

      {/* Quantity + Add to cart */}
      {inStock && (
        <div className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center border border-stone/40">
              <button
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                className="w-10 h-10 flex items-center justify-center text-obsidian/60 hover:text-obsidian hover:bg-stone/20 transition-colors"
              >
                <Minus size={14} />
              </button>
              <span className="w-10 text-center text-sm font-light">{quantity}</span>
              <button
                onClick={() => setQuantity((q) => Math.min(product.stock, q + 1))}
                disabled={quantity >= product.stock}
                className="w-10 h-10 flex items-center justify-center text-obsidian/60 hover:text-obsidian hover:bg-stone/20 transition-colors disabled:opacity-30"
              >
                <Plus size={14} />
              </button>
            </div>
            <span className="text-xs font-light text-stone-dark">
              Max {product.stock} units
            </span>
          </div>

          <div className="flex gap-3">
            <button
              onClick={handleAddToCart}
              disabled={addedToCart}
              className={`flex-1 flex items-center justify-center gap-2 py-4 text-xs tracking-[0.2em] uppercase font-light transition-all duration-300 ${
                addedToCart
                  ? "bg-green-600 text-white"
                  : "bg-obsidian text-cream-50 hover:bg-obsidian-700"
              }`}
            >
              <ShoppingBag size={15} />
              {addedToCart ? "Added to Cart!" : "Add to Cart"}
            </button>
            <button
              onClick={() => setWishlisted(!wishlisted)}
              className="w-12 h-12 border border-stone/40 flex items-center justify-center hover:border-obsidian transition-colors flex-shrink-0"
              aria-label="Add to wishlist"
            >
              <Heart
                size={16}
                className={wishlisted ? "fill-champagne text-champagne" : "text-obsidian/60"}
              />
            </button>
            <button
              onClick={() => navigator.share?.({ title: product.name, url: window.location.href })}
              className="w-12 h-12 border border-stone/40 flex items-center justify-center hover:border-obsidian transition-colors flex-shrink-0"
              aria-label="Share"
            >
              <Share2 size={16} className="text-obsidian/60" />
            </button>
          </div>
        </div>
      )}

      {/* Trust badges */}
      <div className="grid grid-cols-3 gap-3 py-4 border-y border-stone/30">
        {[
          { icon: <Shield size={18} strokeWidth={1.5} />, label: "Lifetime Guarantee" },
          { icon: <Truck size={18} strokeWidth={1.5} />, label: "Free Worldwide Shipping" },
          { icon: <RefreshCw size={18} strokeWidth={1.5} />, label: "30-Day Returns" },
        ].map((b) => (
          <div key={b.label} className="flex flex-col items-center text-center gap-2">
            <div className="text-champagne">{b.icon}</div>
            <p className="text-[9px] tracking-[0.1em] uppercase text-obsidian/60 font-light leading-tight">
              {b.label}
            </p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div>
        <div className="flex gap-0 border-b border-stone/30">
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-3 text-[10px] tracking-[0.2em] uppercase font-light transition-colors border-b-2 -mb-px ${
                activeTab === tab
                  ? "border-champagne text-obsidian"
                  : "border-transparent text-stone-dark hover:text-obsidian"
              }`}
            >
              {tab}
              {tab === "reviews" && reviews.length > 0 && (
                <span className="ml-1 text-champagne">({reviews.length})</span>
              )}
            </button>
          ))}
        </div>

        <div className="pt-5 text-sm font-light text-obsidian/80 leading-relaxed">
          {activeTab === "description" && (
            <div className="whitespace-pre-line">{product.description}</div>
          )}

          {activeTab === "details" && (
            <div className="space-y-3">
              {product.details && <p>{product.details}</p>}
              {product.material && (
                <div className="flex gap-4">
                  <span className="text-[10px] uppercase tracking-[0.15em] text-stone-dark w-24 flex-shrink-0">
                    Material
                  </span>
                  <span>{product.material}</span>
                </div>
              )}
              {product.sku && (
                <div className="flex gap-4">
                  <span className="text-[10px] uppercase tracking-[0.15em] text-stone-dark w-24 flex-shrink-0">
                    SKU
                  </span>
                  <span className="font-mono text-xs">{product.sku}</span>
                </div>
              )}
              {product.dimensions && (
                <div className="flex gap-4">
                  <span className="text-[10px] uppercase tracking-[0.15em] text-stone-dark w-24 flex-shrink-0">
                    Dimensions
                  </span>
                  <span>{product.dimensions}</span>
                </div>
              )}
              {product.weight && (
                <div className="flex gap-4">
                  <span className="text-[10px] uppercase tracking-[0.15em] text-stone-dark w-24 flex-shrink-0">
                    Weight
                  </span>
                  <span>{product.weight}g</span>
                </div>
              )}
            </div>
          )}

          {activeTab === "reviews" && (
            <div className="space-y-6">
              {reviews.length === 0 ? (
                <p className="text-stone-dark">No reviews yet. Be the first to review this product.</p>
              ) : (
                reviews.map((review) => (
                  <div key={review.id} className="border-b border-stone/20 pb-5 last:border-0">
                    <div className="flex items-start justify-between gap-4 mb-2">
                      <div>
                        <p className="text-xs font-medium text-obsidian">
                          {review.user.firstName} {review.user.lastName.charAt(0)}.
                        </p>
                        <div className="flex items-center gap-0.5 mt-1">
                          {[1, 2, 3, 4, 5].map((s) => (
                            <Star
                              key={s}
                              size={10}
                              className={
                                s <= review.rating
                                  ? "fill-champagne text-champagne"
                                  : "text-stone"
                              }
                            />
                          ))}
                        </div>
                      </div>
                      <span className="text-[10px] text-stone-dark flex-shrink-0">
                        {new Date(review.createdAt).toLocaleDateString("en-GB", {
                          day: "numeric",
                          month: "short",
                          year: "numeric",
                        })}
                      </span>
                    </div>
                    {review.title && (
                      <p className="text-xs font-medium text-obsidian mb-1">{review.title}</p>
                    )}
                    {review.body && (
                      <p className="text-xs font-light text-obsidian/70 leading-relaxed">
                        {review.body}
                      </p>
                    )}
                    {review.verified && (
                      <p className="text-[9px] tracking-[0.1em] uppercase text-green-600 mt-2">
                        ✓ Verified purchase
                      </p>
                    )}
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
