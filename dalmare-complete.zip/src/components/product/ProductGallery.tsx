"use client";

import { useState } from "react";
import Image from "next/image";
import { ChevronLeft, ChevronRight, ZoomIn } from "lucide-react";

type Props = {
  images: string[];
  name: string;
};

export function ProductGallery({ images, name }: Props) {
  const [active, setActive] = useState(0);
  const [zoomed, setZoomed] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 50, y: 50 });

  if (!images || images.length === 0) {
    return (
      <div className="aspect-product bg-stone-light flex items-center justify-center">
        <p className="text-stone-dark text-sm">No image</p>
      </div>
    );
  }

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setMousePos({ x, y });
  };

  const prev = () => setActive((a) => (a === 0 ? images.length - 1 : a - 1));
  const next = () => setActive((a) => (a === images.length - 1 ? 0 : a + 1));

  return (
    <div className="space-y-4 sticky top-24">
      {/* Main image */}
      <div
        className="relative aspect-product overflow-hidden bg-stone-light cursor-zoom-in"
        onMouseEnter={() => setZoomed(true)}
        onMouseLeave={() => setZoomed(false)}
        onMouseMove={handleMouseMove}
      >
        <Image
          src={images[active]}
          alt={`${name} — image ${active + 1}`}
          fill
          priority
          quality={90}
          sizes="(max-width: 1024px) 100vw, 50vw"
          className={`object-cover transition-transform duration-200 ${
            zoomed ? "scale-150" : "scale-100"
          }`}
          style={
            zoomed
              ? { transformOrigin: `${mousePos.x}% ${mousePos.y}%` }
              : undefined
          }
        />

        {/* Nav arrows */}
        {images.length > 1 && (
          <>
            <button
              onClick={prev}
              className="absolute left-3 top-1/2 -translate-y-1/2 w-9 h-9 bg-cream-50/80 backdrop-blur-sm flex items-center justify-center hover:bg-cream-50 transition-colors opacity-0 group-hover:opacity-100 transition-opacity"
              aria-label="Previous image"
            >
              <ChevronLeft size={16} />
            </button>
            <button
              onClick={next}
              className="absolute right-3 top-1/2 -translate-y-1/2 w-9 h-9 bg-cream-50/80 backdrop-blur-sm flex items-center justify-center hover:bg-cream-50 transition-colors"
              aria-label="Next image"
            >
              <ChevronRight size={16} />
            </button>
          </>
        )}

        {/* Zoom hint */}
        {!zoomed && (
          <div className="absolute bottom-3 right-3 flex items-center gap-1.5 bg-cream-50/70 backdrop-blur-sm px-2.5 py-1.5">
            <ZoomIn size={12} className="text-obsidian/60" />
            <span className="text-[9px] tracking-[0.15em] uppercase text-obsidian/60">Hover to zoom</span>
          </div>
        )}

        {/* Counter */}
        {images.length > 1 && (
          <div className="absolute bottom-3 left-3 bg-cream-50/70 backdrop-blur-sm px-2.5 py-1.5">
            <span className="text-[9px] tracking-[0.1em] text-obsidian/60">
              {active + 1} / {images.length}
            </span>
          </div>
        )}
      </div>

      {/* Thumbnails */}
      {images.length > 1 && (
        <div className="flex gap-2 overflow-x-auto pb-1">
          {images.map((img, i) => (
            <button
              key={i}
              onClick={() => setActive(i)}
              className={`relative w-16 h-20 flex-shrink-0 overflow-hidden border-2 transition-all duration-200 ${
                i === active
                  ? "border-champagne"
                  : "border-transparent opacity-60 hover:opacity-100"
              }`}
            >
              <Image
                src={img}
                alt={`${name} thumbnail ${i + 1}`}
                fill
                className="object-cover"
                sizes="64px"
              />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
