// PromoBanner.tsx
import Image from "next/image";
import Link from "next/link";

export function PromoBanner() {
  return (
    <section className="relative h-[400px] md:h-[500px] overflow-hidden">
      <Image
        src="https://images.unsplash.com/photo-1590736969596-0c44c2b0e9e4?w=1600&q=80"
        alt="Dalmare campaign"
        fill
        className="object-cover"
        sizes="100vw"
      />
      <div className="absolute inset-0 bg-obsidian/60" />
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-6">
        <p className="text-[10px] tracking-[0.4em] uppercase text-champagne mb-4 font-light">
          Limited Offer
        </p>
        <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-light text-white mb-4">
          Up to 30% Off
          <br />
          <em className="italic text-champagne">Selected Pieces</em>
        </h2>
        <p className="text-sm font-light text-white/70 mb-8 max-w-sm">
          Exclusive discounts on our most sought-after collections. Limited time only.
        </p>
        <Link href="/shop?filter=sale" className="btn-gold">
          Shop the Sale
        </Link>
      </div>
    </section>
  );
}
