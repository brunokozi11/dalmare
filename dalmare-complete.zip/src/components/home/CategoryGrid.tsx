import Image from "next/image";
import Link from "next/link";

const categories = [
  {
    name: "Timepieces",
    description: "Precision & elegance",
    image: "https://images.unsplash.com/photo-1523170335258-f5ed11844a49?w=800&q=80",
    href: "/shop?category=watches",
    span: "lg:col-span-2",
  },
  {
    name: "Necklaces",
    description: "Refined luxury",
    image: "https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=800&q=80",
    href: "/shop?category=jewellery&type=necklaces",
    span: "",
  },
  {
    name: "Bracelets",
    description: "Subtle statements",
    image: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=800&q=80",
    href: "/shop?category=jewellery&type=bracelets",
    span: "",
  },
];

export function CategoryGrid() {
  return (
    <section className="py-20 px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <p className="section-subtitle mb-3">Our Collections</p>
          <div className="divider-gold mb-4" />
        </div>

        {/* Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {categories.map((cat) => (
            <Link
              key={cat.name}
              href={cat.href}
              className={`group relative overflow-hidden ${cat.span} aspect-[3/4] lg:aspect-auto lg:h-[500px]`}
            >
              <Image
                src={cat.image}
                alt={cat.name}
                fill
                sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 50vw"
                className="object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-obsidian/70 via-transparent to-transparent transition-opacity duration-300 group-hover:from-obsidian/80" />
              <div className="absolute bottom-0 left-0 right-0 p-6 translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                <h3 className="font-display text-2xl font-light text-white">{cat.name}</h3>
                <p className="text-xs tracking-[0.2em] uppercase text-white/60 mt-1 font-light">
                  {cat.description}
                </p>
                <div className="flex items-center gap-2 mt-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <span className="text-[10px] tracking-[0.2em] uppercase text-champagne font-light">
                    Explore
                  </span>
                  <div className="w-6 h-px bg-champagne" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
