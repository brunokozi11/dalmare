import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { ProductCard } from "@/components/shop/ProductCard";

async function getBestSellers() {
  try {
    return await prisma.product.findMany({
      where: { bestSeller: true, active: true },
      include: { category: true },
      take: 4,
    });
  } catch {
    return [];
  }
}

export async function BestSellers() {
  const products = await getBestSellers();
  if (products.length === 0) return null;

  return (
    <section className="py-20 px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <p className="section-subtitle mb-3">Most Loved</p>
            <h2 className="section-title">Best Sellers</h2>
            <div className="divider-gold mt-4 mx-0" />
          </div>
          <Link
            href="/shop?filter=bestsellers"
            className="inline-flex items-center gap-2 text-xs tracking-[0.2em] uppercase font-light text-champagne hover:text-champagne-dark transition-colors"
          >
            View All
            <ArrowRight size={14} />
          </Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 md:gap-8">
          {products.map((product) => (
            <ProductCard key={product.id} product={product as any} />
          ))}
        </div>
      </div>
    </section>
  );
}
