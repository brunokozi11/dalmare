"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { ArrowRight } from "lucide-react";

const slides = [
  {
    image: "https://images.unsplash.com/photo-1614164185128-e4ec99c436d7?w=1920&q=85",
    tagline: "New Collection 2025",
    title: "The Art of Time",
    subtitle: "Exquisitely crafted timepieces for those who seek the extraordinary",
    cta: "Explore Watches",
    href: "/shop?category=watches",
  },
  {
    image: "https://images.unsplash.com/photo-1506630448388-4e683c67ddb0?w=1920&q=85",
    tagline: "Fine Jewellery",
    title: "Wear Your Story",
    subtitle: "Handcrafted jewellery that speaks before words can",
    cta: "Discover Jewellery",
    href: "/shop?category=jewellery",
  },
  {
    image: "https://images.unsplash.com/photo-1611085583191-a3b181a88401?w=1920&q=85",
    tagline: "Limited Edition",
    title: "Crafted Luxury",
    subtitle: "Each piece is a testament to uncompromising craftsmanship",
    cta: "Shop Now",
    href: "/shop",
  },
];

export function HeroSection() {
  const [current, setCurrent] = useState(0);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    setLoaded(true);
    const interval = setInterval(() => {
      setCurrent((prev) => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const slide = slides[current];

  return (
    <section className="relative h-[100svh] min-h-[600px] overflow-hidden">
      {/* Background images */}
      {slides.map((s, i) => (
        <div
          key={i}
          className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
            i === current ? "opacity-100" : "opacity-0"
          }`}
        >
          <Image
            src={s.image}
            alt={s.title}
            fill
            priority={i === 0}
            quality={85}
            className="object-cover"
            sizes="100vw"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-obsidian/10 via-obsidian/20 to-obsidian/70" />
        </div>
      ))}

      {/* Vertical text decoration */}
      <div className="hidden lg:flex absolute left-8 top-1/2 -translate-y-1/2 flex-col items-center gap-4 z-10">
        <div className="w-px h-20 bg-white/30" />
        <span className="writing-vertical text-[10px] tracking-[0.3em] uppercase text-white/50 font-light">
          Luxury Accessories
        </span>
        <div className="w-px h-20 bg-white/30" />
      </div>

      {/* Content */}
      <div
        className={`absolute inset-0 flex flex-col items-center justify-center text-center px-6 z-10 transition-all duration-700 ${
          loaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
        }`}
      >
        <p
          key={`tag-${current}`}
          className="text-[11px] tracking-[0.4em] uppercase text-champagne font-light mb-6 animate-fade-up"
          style={{ animationDelay: "0.1s" }}
        >
          {slide.tagline}
        </p>
        <h1
          key={`title-${current}`}
          className="font-display text-display-2xl font-light text-white mb-6 animate-fade-up"
          style={{ animationDelay: "0.2s" }}
        >
          {slide.title}
        </h1>
        <p
          key={`sub-${current}`}
          className="text-base md:text-lg font-light text-white/75 mb-10 max-w-lg animate-fade-up"
          style={{ animationDelay: "0.35s" }}
        >
          {slide.subtitle}
        </p>
        <Link
          href={slide.href}
          className="inline-flex items-center gap-3 text-xs tracking-[0.25em] uppercase font-light text-white border border-white/50 px-8 py-4 hover:bg-white hover:text-obsidian transition-all duration-300 animate-fade-up"
          style={{ animationDelay: "0.5s" }}
        >
          {slide.cta}
          <ArrowRight size={14} className="transition-transform duration-300 group-hover:translate-x-1" />
        </Link>
      </div>

      {/* Slide indicators */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex items-center gap-3 z-10">
        {slides.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrent(i)}
            className={`transition-all duration-500 ${
              i === current
                ? "w-8 h-px bg-champagne"
                : "w-4 h-px bg-white/40 hover:bg-white/60"
            }`}
            aria-label={`Go to slide ${i + 1}`}
          />
        ))}
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-10 right-8 hidden md:flex flex-col items-center gap-2 z-10">
        <span className="text-[9px] tracking-[0.3em] uppercase text-white/40">Scroll</span>
        <div className="w-px h-12 bg-white/20 relative overflow-hidden">
          <div className="absolute top-0 w-full h-1/2 bg-champagne animate-float" />
        </div>
      </div>
    </section>
  );
}
