"use client";

import { useState } from "react";
import { ArrowRight } from "lucide-react";

export function NewsletterSection() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setStatus("loading");
    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      if (res.ok) {
        setStatus("success");
        setEmail("");
      } else {
        setStatus("error");
      }
    } catch {
      setStatus("error");
    }
  };

  return (
    <section className="py-20 px-6 md:px-12 bg-cream-200 relative overflow-hidden">
      {/* Decorative element */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none">
        <span className="font-display text-[20rem] font-light text-obsidian leading-none select-none">
          D
        </span>
      </div>

      <div className="max-w-2xl mx-auto text-center relative">
        <p className="section-subtitle mb-3">Stay Connected</p>
        <h2 className="section-title mb-4">
          Join the <em className="font-display italic text-champagne">Dalmare</em> Circle
        </h2>
        <div className="divider-gold mb-6" />
        <p className="text-sm font-light text-obsidian/60 mb-10 max-w-md mx-auto">
          Be the first to discover new collections, exclusive events, and the stories
          behind each piece. Plus, enjoy 10% off your first order.
        </p>

        {status === "success" ? (
          <div className="py-4">
            <p className="text-sm font-light text-champagne tracking-[0.1em]">
              Welcome to the circle. Your 10% discount is on its way.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 max-w-sm mx-auto">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              required
              className="flex-1 border-b border-obsidian/30 bg-transparent px-0 py-3 text-sm font-light placeholder-obsidian/40 focus:outline-none focus:border-champagne transition-colors"
            />
            <button
              type="submit"
              disabled={status === "loading"}
              className="btn-primary whitespace-nowrap disabled:opacity-50"
            >
              {status === "loading" ? "..." : (
                <>Subscribe <ArrowRight size={12} /></>
              )}
            </button>
          </form>
        )}

        {status === "error" && (
          <p className="text-xs text-red-500 mt-3">Something went wrong. Please try again.</p>
        )}

        <p className="text-[10px] tracking-[0.1em] text-obsidian/35 mt-6 uppercase">
          No spam, ever. Unsubscribe anytime.
        </p>
      </div>
    </section>
  );
}
