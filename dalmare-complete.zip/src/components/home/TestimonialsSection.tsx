"use client";

import { useState } from "react";
import { Star, Quote } from "lucide-react";

const testimonials = [
  {
    name: "Sophie Laurent",
    location: "Paris, France",
    rating: 5,
    text: "The Dalmare watch I received is absolutely stunning. The quality exceeded my expectations — it feels like a piece that will be passed down for generations.",
    product: "Caratello Automatic",
  },
  {
    name: "Marcus Heinz",
    location: "Vienna, Austria",
    rating: 5,
    text: "I purchased a bracelet set as a gift. The packaging alone was worth the price — pure luxury from unboxing to wearing. My partner was speechless.",
    product: "Arco Steel Set",
  },
  {
    name: "Isabella Romano",
    location: "Milan, Italy",
    rating: 5,
    text: "As someone with an eye for Italian design, Dalmare genuinely delivers. The attention to detail is remarkable. These pieces belong in any serious collection.",
    product: "Solara Necklace",
  },
];

export function TestimonialsSection() {
  const [active, setActive] = useState(0);

  return (
    <section className="py-20 px-6 md:px-12 bg-obsidian">
      <div className="max-w-4xl mx-auto text-center">
        <p className="section-subtitle text-champagne mb-3">Customer Reviews</p>
        <h2 className="font-display text-display-lg font-light text-cream-50 mb-4">
          Worn & Loved
        </h2>
        <div className="divider-gold mb-16" />

        {/* Active testimonial */}
        <div className="relative min-h-[200px]">
          <Quote
            size={40}
            className="text-champagne/20 mx-auto mb-6"
            strokeWidth={1}
          />
          <div className="flex justify-center gap-1 mb-6">
            {Array(testimonials[active].rating).fill(0).map((_, i) => (
              <Star key={i} size={14} className="fill-champagne text-champagne" />
            ))}
          </div>
          <blockquote className="font-display text-lg md:text-xl font-light italic text-cream-50/90 leading-relaxed mb-8 max-w-2xl mx-auto">
            "{testimonials[active].text}"
          </blockquote>
          <p className="text-sm font-light text-cream-50/70">
            {testimonials[active].name}
            <span className="text-stone-medium mx-2">·</span>
            {testimonials[active].location}
          </p>
          <p className="text-[10px] tracking-[0.2em] uppercase text-champagne mt-1 font-light">
            {testimonials[active].product}
          </p>
        </div>

        {/* Selectors */}
        <div className="flex justify-center gap-4 mt-10">
          {testimonials.map((_, i) => (
            <button
              key={i}
              onClick={() => setActive(i)}
              className={`h-px transition-all duration-300 ${
                i === active ? "w-8 bg-champagne" : "w-4 bg-cream-50/30 hover:bg-cream-50/50"
              }`}
              aria-label={`View testimonial ${i + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
