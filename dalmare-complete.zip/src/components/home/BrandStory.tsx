import Image from "next/image";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

export function BrandStory() {
  return (
    <section className="py-24 px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Images */}
          <div className="relative">
            <div className="relative aspect-[4/5] w-full max-w-lg">
              <Image
                src="https://images.unsplash.com/photo-1601541895929-9bd0d0c5db75?w=800&q=80"
                alt="Dalmare atelier"
                fill
                className="object-cover"
                sizes="(max-width: 1024px) 100vw, 50vw"
              />
            </div>
            {/* Floating accent card */}
            <div className="absolute -bottom-8 -right-0 lg:right-0 bg-cream-50 border border-stone/40 p-8 shadow-luxury max-w-[260px]">
              <p className="font-display text-4xl font-light text-champagne mb-1">Est.</p>
              <p className="font-display text-5xl font-light text-obsidian">2018</p>
              <div className="w-8 h-px bg-champagne my-4" />
              <p className="text-xs font-light text-stone-dark tracking-[0.1em] leading-relaxed">
                Founded with a passion for timeless elegance
              </p>
            </div>
          </div>

          {/* Content */}
          <div className="lg:pl-8">
            <p className="section-subtitle mb-4">Our Story</p>
            <h2 className="font-display text-display-lg font-light text-obsidian leading-tight mb-6">
              Where Craft Meets{" "}
              <em className="italic text-champagne">Timeless</em> Beauty
            </h2>
            <div className="divider-gold mb-8 mx-0" />

            <div className="space-y-5 text-sm font-light text-obsidian/70 leading-relaxed">
              <p>
                Dalmare was born from a deep appreciation for the art of fine watchmaking and
                jewellery crafting. We believe that true luxury lies not in excess, but in the
                quiet confidence of a perfectly crafted piece.
              </p>
              <p>
                Each Dalmare creation begins as a sketch on paper and goes through countless
                hours of refinement before it reaches your hands. We source only the finest
                316L stainless steel, sapphire crystals, and precious metals, ensuring that
                every piece stands the test of time.
              </p>
              <p>
                Our commitment to quality extends beyond the product. From the moment you
                browse our collection to the day your piece arrives in its signature packaging,
                we strive to make every interaction feel extraordinary.
              </p>
            </div>

            <div className="grid grid-cols-3 gap-6 my-10 py-8 border-y border-stone/30">
              {[
                { number: "25k+", label: "Happy Customers" },
                { number: "200+", label: "Unique Designs" },
                { number: "7yr", label: "Of Excellence" },
              ].map((stat) => (
                <div key={stat.label} className="text-center">
                  <p className="font-display text-3xl font-light text-champagne mb-1">{stat.number}</p>
                  <p className="text-[10px] tracking-[0.15em] uppercase text-stone-dark font-light">
                    {stat.label}
                  </p>
                </div>
              ))}
            </div>

            <Link href="/about" className="inline-flex items-center gap-3 btn-secondary">
              Discover Our Story
              <ArrowRight size={14} />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
