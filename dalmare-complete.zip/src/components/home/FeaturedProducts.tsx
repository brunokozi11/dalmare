import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { ProductCard } from "@/components/shop/ProductCard";

async function getFeaturedProducts() {
  try {
    return await prisma.product.findMany({
      where: { featured: true, active: true },
      include: { category: true },
      take: 4,
      orderBy: { createdAt: "desc" },
    });
  } catch {
    return [];
  }
}

export async function FeaturedProducts() {
  const products = await getFeaturedProducts();

  // Fallback if no products yet
  if (products.length === 0) {
    return (
      <section className="py-20 px-6 md:px-12 bg-stone-light">
        <div className="max-w-7xl mx-auto text-center">
          <p className="section-subtitle mb-3">Featured</p>
          <h2 className="section-title mb-4">Curated Selection</h2>
          <div className="divider-gold mb-16" />
          <p className="text-sm font-light text-stone-dark">
            Products will appear here once added to your store.
          </p>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 px-6 md:px-12 bg-stone-light">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <p className="section-subtitle mb-3">Featured</p>
            <h2 className="section-title">Curated Selection</h2>
            <div className="divider-gold mt-4 mx-0" />
          </div>
          <Link
            href="/shop"
            className="inline-flex items-center gap-2 text-xs tracking-[0.2em] uppercase font-light text-champagne hover:text-champagne-dark transition-colors"
          >
            View All
            <ArrowRight size={14} />
          </Link>
        </div>

        {/* Products grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 md:gap-8">
          {products.map((product, i) => (
            <ProductCard
              key={product.id}
              product={product as any}
              priority={i < 2}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
